#!/usr/bin/env python3
"""Compile extracted production policy/dispatch functions with explicit cache stubs.

This validates policy and callback routing, not Vulkan transfers, guest semantics,
OS signal reentrancy, performance, shader indexing, or GPU/gameplay execution.
"""
from __future__ import annotations
import argparse, json, subprocess
from pathlib import Path
import patch_coherence as patch
HERE=Path(__file__).resolve().parent
TRACKER='src/video_core/buffer_cache/memory_tracker.h'
REGION='src/video_core/buffer_cache/region_manager.h'
TRACKER_BLOB='2546a2d54102aad759816adeee3f6e0cbe2cc06e'
REGION_BLOB='ba82498ec154cdc0c039cf749d6c84676f54aa6d'

PREFIX = r'''
#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <iostream>
#include <memory>
#include <optional>
#include <stdexcept>
#include <utility>
#include <vector>
using u32=std::uint32_t; using u64=std::uint64_t; using VAddr=u64;
enum GpuReadbacksMode : int { Disabled, Relaxed, Precise };
enum class ConfigMode { Default, Global, Clean };
template<class T> struct Setting {
 T default_value{},value{}; std::optional<T> game_specific_value{};
 T get(ConfigMode mode) const {
  if(mode==ConfigMode::Global)return value;
  if(mode==ConfigMode::Clean)return default_value;
  return game_specific_value.value_or(value);
 }
 void set(T v,bool game){if(game)game_specific_value=v;else value=v;}
};
#define SETTING_FORWARD(group, Name, field) \
 auto Get##Name() const {return (group).field.get(m_configMode);} \
 void Set##Name(const decltype((group).field.value)& v,bool specific=false){(group).field.set(v,specific);}
struct Settings {
 struct GPU { Setting<u32> readbacks_mode; } m_gpu;
 ConfigMode m_configMode{};
 bool uffd{};
 bool IsUserfaultfdTracking()const{return uffd;}
__ACCESSORS__
};
Settings EmulatorSettings;
enum class Type : unsigned { CPU=1,GPU=2 };
enum class StateOp { None,Set,Clear };
enum class PageOp { None,Track,Untrack };
struct RegionManager {
 bool dirty{},cpu_dirty{},locked{};
 int transitions{};
 u32 readbacks_mode=EmulatorSettings.GetReadbacksMode();
__WATCHER__
 u64 GetBounds(u64 offset,u64)const{return offset;}
 void Lock(u64){locked=true;}
 void Unlock(u64){locked=false;}
 template<Type T> bool IsRegionModified(u64,u64)const{
  static_assert(T==Type::GPU);return dirty;
 }
 template<StateOp CPU,StateOp GPU,bool Locked> void ChangeRegionState(u64,u64){
  static_assert(CPU==StateOp::Set&&GPU==StateOp::None&&!Locked);
  cpu_dirty=true;++transitions;
 }
};
struct Tracker {
 std::vector<RegionManager> pages=std::vector<RegionManager>(3);
 u32 readbacks_mode=EmulatorSettings.GetReadbacksMode();
 template<class F> void IteratePages(u64 start,u64 size,F&&f){
  for(u64 n=start;n<start+size;++n)f(&pages.at(n),n,1);
 }
 void MarkRegionAsCpuModified(u64 start,u64 size){
  for(u64 n=start;n<start+size;++n)pages.at(n).cpu_dirty=true;
 }
__INVALIDATE__
};
namespace Vulkan {struct Rasterizer {};}
struct Backend {virtual ~Backend()=default;virtual bool reads()const=0;};
struct UffdImpl:Backend {explicit UffdImpl(Vulkan::Rasterizer*){} bool reads()const override{return false;}};
struct SignalImpl:Backend {explicit SignalImpl(Vulkan::Rasterizer*){} bool reads()const override{return true;}};
#define LOG_INFO(...) ((void)0)
struct PageManager {std::unique_ptr<Backend> impl;explicit PageManager(Vulkan::Rasterizer*);};
__BACKEND__
static void check(bool x,const char*reason){if(!x)throw std::runtime_error(reason);}
'''
SUFFIX = r'''
int main(){try{
 unsigned combinations=0;
 for(u32 legacy:{0u,1u,2u,3u,0xffffffffu})
 for(u32 per_game:{0u,1u,2u})
 for(auto mode:{ConfigMode::Default,ConfigMode::Global,ConfigMode::Clean})
 for(bool uffd:{false,true}){
  EmulatorSettings.m_gpu.readbacks_mode={legacy,legacy,per_game};
  EmulatorSettings.m_configMode=mode;EmulatorSettings.uffd=uffd;
  check(EmulatorSettings.GetReadbacksMode()==GpuReadbacksMode::Precise,"legacy option disabled correctness");
  const auto saved=EmulatorSettings.m_gpu.readbacks_mode;
  EmulatorSettings.SetReadbacksMode(0,true);EmulatorSettings.SetReadbacksMode(0,false);
  check(EmulatorSettings.GetReadbacksMode()==GpuReadbacksMode::Precise,"frontend disabled correctness");
  check(EmulatorSettings.m_gpu.readbacks_mode.value==saved.value&&
    EmulatorSettings.m_gpu.readbacks_mode.game_specific_value==saved.game_specific_value,
    "policy silently rewrote settings");
  RegionManager region;
  check(region.GetPageOp<Type::GPU>(StateOp::Set)==PageOp::Track,"GPU dirty page is not read-watched");
  check(region.GetPageOp<Type::GPU>(StateOp::Clear)==PageOp::Untrack,"read watch not removed after synchronization");
  check(region.GetPageOp<Type::GPU>(StateOp::None)==PageOp::None,"clean page needs no new read watch");
  check(region.GetPageOp<Type::CPU>(StateOp::Clear)==PageOp::Track,"CPU write watch changed");
  check(region.GetPageOp<Type::CPU>(StateOp::Set)==PageOp::Untrack,"CPU write unwatch changed");
  Tracker tracker;unsigned flushes=0;
  tracker.InvalidateRegion(0,1,[&]{++flushes;});
  check(flushes==0,"clean CPU access caused download");
  tracker.pages[1].dirty=true;tracker.pages[2].dirty=true;
  check(flushes==0,"marking GPU dirtiness downloaded memory without CPU demand");
  tracker.InvalidateRegion(1,1,[&]{
   check(!tracker.pages[1].locked,"flush invoked while tracker lock held");
   ++flushes;tracker.pages[1].dirty=false;
  });
  check(flushes==1&&tracker.pages[2].dirty,"demand flushed unrelated dirty page");
  tracker.InvalidateRegion(1,1,[&]{++flushes;});
  check(flushes==1,"repeated clean access downloaded again");
  tracker.pages[1].dirty=true;
  tracker.InvalidateRegion(1,1,[&]{++flushes;tracker.pages[1].dirty=false;});
  check(flushes==2,"new GPU write failed to rearm demand");
  tracker.InvalidateRegion(0,0,[&]{++flushes;});
  check(flushes==2,"empty demand flushed");
  Vulkan::Rasterizer raster;PageManager backend(&raster);
  check(backend.impl->reads(),"write-only tracker chosen for CPU read faults");
  ++combinations;
 }
 std::cout<<"AUTOMATIC_COHERENCE_POLICY=PASS combinations="<<combinations
 <<" clean_no_flush=YES dirty_demand_flush=YES unrelated_dirty_preserved=YES"
 <<" repeated_clean_no_flush=YES write_only_backend_rejected=YES\n";
 return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 2;}}
'''


def build_text(fragments, fixed=True, old_backend=False):
    accessors=patch.NEW_ACCESSORS if fixed else fragments['settings']
    backend=fragments['backend']
    if fixed and not old_backend:
        backend=patch.once(backend,patch.OLD_BACKEND,patch.NEW_BACKEND)
    text=PREFIX
    for key,value in [('__ACCESSORS__',accessors),('__WATCHER__',fragments['watcher']),
                      ('__INVALIDATE__',fragments['invalidate']),('__BACKEND__',backend)]:
        text=patch.once(text,key,value)
    return text+SUFFIX


def verify(compiler,out,source=None,sanitize=False):
    out.mkdir(parents=True,exist_ok=True)
    fragments=json.loads((HERE/'source_fragments.json').read_text())
    if source is not None:
        def get(path):return (source/path).read_bytes()
        for path,expected,key in [(TRACKER,TRACKER_BLOB,'invalidate'),(REGION,REGION_BLOB,'watcher')]:
            data=get(path)
            if patch.blob(data)!=expected or fragments[key] not in data.decode():
                raise RuntimeError('UNCHANGED_TRACKER_FUNCTION_MISMATCH='+path)
        if patch.NEW_ACCESSORS not in get(patch.SETTINGS).decode():
            raise RuntimeError('POLICY_NOT_IN_CHECKED_OUT_SOURCE')
        if patch.once(fragments['backend'],patch.OLD_BACKEND,patch.NEW_BACKEND) not in get(patch.PAGES).decode():
            raise RuntimeError('READ_CAPABLE_BACKEND_NOT_IN_CHECKED_OUT_SOURCE')
    flags=[compiler,'-std=c++23','-O1','-Wall','-Wextra','-Werror']
    if sanitize:flags+=['-fsanitize=address,undefined','-fno-omit-frame-pointer']
    logs=[]
    for name,text,expected in [('new',build_text(fragments),0),
            ('old-policy',build_text(fragments,False),2),
            ('old-backend',build_text(fragments,True,True),2)]:
        cpp=out/(name+'.cpp');exe=out/name;cpp.write_text(text)
        compile_run=subprocess.run([*flags,str(cpp),'-o',str(exe)],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=90)
        logs.append(compile_run.stdout)
        if compile_run.returncode:
            (out/'verification.log').write_text(''.join(logs));raise RuntimeError('TEST_COMPILATION_FAILED='+name+'\n'+compile_run.stdout)
        result=subprocess.run([str(exe)],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30)
        logs.append(name+': '+result.stdout)
        if result.returncode!=expected:
            (out/'verification.log').write_text(''.join(logs));raise RuntimeError('UNEXPECTED_TEST_RESULT='+name+'\n'+result.stdout)
    (out/'verification.log').write_text(''.join(logs))
    print(''.join(logs),end='')
    print('NEGATIVE_CONTROLS=OLD_CONFIG_POLICY_AND_WRITE_ONLY_BACKEND_REJECTED')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--compiler',default='c++');p.add_argument('--output',type=Path,required=True)
    p.add_argument('--source',type=Path);p.add_argument('--sanitize',action='store_true');a=p.parse_args()
    verify(a.compiler,a.output,a.source,a.sanitize)
