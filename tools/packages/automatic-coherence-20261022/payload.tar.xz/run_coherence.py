#!/usr/bin/env python3
"""Build-only automatic-coherence candidate on the last complete clean source.

No game launch, settings edit, save reset, driver override or experimental feature
flag. Reuse the hash-verified native build/restore workflow without replaying its
old patch stack. The visually progressing reference is never overwritten.
"""
from __future__ import annotations
import ast, hashlib, importlib.util, json, os, subprocess, sys, tarfile, tempfile
from pathlib import Path
import patch_coherence as patch

PARENT='27e3a68a6a96f2aa6bab42df50a32f2cbf0f2d77'
TREE='40ad46ae118d3d6c2112eed0d821d0b4cd0d146e'
BINARY_SHA='0f4c42c2e1c14ed382a324b71a8434cc5c0009d87e05411b3bd3ee47519b39e8'
REPORT_DIR='masked-wave-build-20261022-192858-3708297'
REPORT_SHA='87fa2869276f340833be724659d07f03a63e2d45e5ea736c64d729f08373d05b'
MANIFEST_SHA='d3e003ab0497faed0e0cc323c81faffa38e9c070531db47825789f526d03f80b'
SIRIT='471ebbd5f08047a9ece7f5f3766c848c37c8b580'
ATOMIC='8329755a6da9c1827c3153de4f82d0638ee19ff8'
ATOMIC_SHA='1aedac41041fd34210325729506b15336df0a5df9b1f5dbd1b358493f773a197'
PACKAGE=Path(__file__).resolve().parent
REQUIRED={'run_coherence.py','patch_coherence.py','verify_coherence.py',
          'source_fragments.json'}


def digest(path):
    if path.is_symlink() or not path.is_file():raise RuntimeError('EXPECTED_REGULAR_FILE='+str(path))
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def verify_package(package):
    m=package/'MANIFEST.json'
    if m.is_symlink() or not m.is_file():raise RuntimeError('MANIFEST_MISSING')
    records=json.loads(m.read_bytes())
    if not isinstance(records,dict) or not REQUIRED.issubset(records):raise RuntimeError('INCOMPLETE_PACKAGE')
    for name,expected in records.items():
        if not isinstance(name,str) or Path(name).name!=name or name.startswith('.') or name=='MANIFEST.json':
            raise RuntimeError('UNSAFE_PACKAGE_PATH')
        if digest(package/name)!=expected:raise RuntimeError('PACKAGE_CHECKSUM_MISMATCH='+name)
        if name.endswith('.py'):ast.parse((package/name).read_bytes(),filename=name)


def verify_parent(job,native):
    folder=job.root/'logs'/REPORT_DIR/'info'
    if digest(folder/'build-result.json')!=REPORT_SHA or digest(folder/'correction.json')!=MANIFEST_SHA:
        raise RuntimeError('LATEST_BUILD_EVIDENCE_CHANGED')
    report=json.loads((folder/'build-result.json').read_bytes())
    expected={'revision':PARENT,'tree':TREE,'candidate_sha256':BINARY_SHA,'full_build':'PASS',
              'source_restored':True,'build_binary_restored':True,'sirit_restored':True,
              'game_started':False,'manifest_sha256':MANIFEST_SHA,'exit':0}
    if any(report.get(k)!=v for k,v in expected.items()):raise RuntimeError('LATEST_PARENT_BUILD_NOT_VERIFIED')
    candidate=job.root/f'clean-rebase-verified/candidates/{PARENT}-{BINARY_SHA}/shadps4'
    if Path(report['candidate'])!=candidate or digest(candidate)!=BINARY_SHA:raise RuntimeError('LATEST_BUILT_EXECUTABLE_CHANGED')
    if job.git('rev-parse',PARENT+'^{tree}').decode().strip()!=TREE:raise RuntimeError('LATEST_PARENT_TREE_CHANGED')
    if job.git('rev-parse',PARENT+':'+native.SIRIT).decode().strip()!=SIRIT:raise RuntimeError('LATEST_SIRIT_PIN_CHANGED')
    manifest=json.loads((folder/'correction.json').read_bytes())
    if set(job.git('diff','--name-only',native.base.BASE,PARENT).decode().splitlines())!=set(manifest['files']):
        raise RuntimeError('PARENT_MANIFEST_FILE_SET_CHANGED')
    for name,record in manifest['files'].items():
        if job.git('rev-parse',PARENT+':'+name).decode().strip()!=record['corrected_blob']:
            raise RuntimeError('PARENT_MANIFEST_BLOB_CHANGED='+name)
    for name in ('build-result.json','correction.json'):
        (job.info/('coherence-parent-'+name)).write_bytes((folder/name).read_bytes())
    return manifest


def install_delta(job,native,manifest,updates):
    if set(updates)!=set(patch.EXPECTED):raise RuntimeError('UNEXPECTED_COHERENCE_CHANGESET')
    if job.git('rev-parse',PARENT+'^{tree}').decode().strip()!=TREE:raise RuntimeError('PARENT_TREE_CHANGED')
    changed_manifest=json.loads(json.dumps(manifest))
    env=dict(native.base.ENV,GIT_INDEX_FILE=str(job.run/'automatic-coherence-index'))
    job.git('read-tree',PARENT,env=env)
    for path,data in updates.items():
        if job.git('rev-parse',PARENT+':'+path).decode().strip()!=patch.EXPECTED[path]:
            raise RuntimeError('PRODUCTION_PREIMAGE_CHANGED='+path)
        oid=job.git('hash-object','-w','--stdin',input_data=data).decode().strip()
        if oid!=patch.blob(data):raise RuntimeError('SOURCE_OBJECT_WRITE_MISMATCH')
        job.git('update-index','--add','--cacheinfo',f'100644,{oid},{path}',env=env)
        changed_manifest['files'][path]={'original_blob':patch.EXPECTED[path],
          'corrected_blob':oid,'sha256':hashlib.sha256(data).hexdigest()}
    tree=job.git('write-tree',env=env).decode().strip()
    rev=job.git('commit-tree',tree,'-p',PARENT,input_data=(
        'Make existing demand-driven GPU/CPU coherence mandatory for every title\n\n'
        'Ignore legacy Disabled/Relaxed renderer selections without rewriting saved configs. '
        'Retain precise dirty-page-triggered readbacks and existing waits/copy batching; do not '
        'add frame-wide downloads or change shader implementations. Select read-capable signal '
        'tracking rather than write-only userfaultfd when CPU read faults are required. '
        'This does not restore missing dynamic descriptor-table support or prove gameplay.\n'
    ).encode()).decode().strip()
    if set(job.git('diff','--name-only',PARENT,rev).decode().splitlines())!=set(updates):
        raise RuntimeError('INCREMENTAL_PRODUCTION_DELTA_CHANGED')
    if set(job.git('diff','--name-only',native.base.BASE,rev).decode().splitlines())!=set(changed_manifest['files']):
        raise RuntimeError('RETAINED_FIX_SET_CHANGED')
    if job.git('rev-parse',rev+'^').decode().strip()!=PARENT or job.git('rev-parse',rev+':'+native.SIRIT).decode().strip()!=SIRIT:
        raise RuntimeError('CANDIDATE_PARENT_OR_DEPENDENCY_CHANGED')
    changed_manifest['parent']=PARENT
    changed_manifest['automatic_coherence']={
        'parent_tree':TREE,'incremental_files':sorted(updates),
        'implementation':'existing precise page-fault-demand path, no blanket frame downloads',
        'legacy_readback_selection':'accepted for compatibility, ignored for effective policy',
        'linux_backend':'read-capable signals; current write-only UFFD cannot be used',
        'shader_code_changed':False,'indexed_resource_port_included':False,
        'gpu_runtime_verified':False,'all_game_compatibility_verified':False}
    native.base.write_json(job.info/'correction.json',changed_manifest)
    (job.info/'correction.patch').write_bytes(job.git('diff',native.base.BASE,rev,'--'))
    (job.info/'automatic-coherence.patch').write_bytes(job.git('diff',PARENT,rev,'--'))
    for path,data in updates.items():
        dest=job.stage/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
    job.git('update-ref','refs/heads/local/automatic-coherence-'+rev[:12],rev)
    native.NEW_SIRIT=SIRIT
    job.revision=rev
    job.report.update(revision=rev,tree=tree,source_parent=PARENT,sirit_candidate=SIRIT,
        manifest_sha256=native.base.digest(job.info/'correction.json'),
        automatic_coherence='EXISTING_PRECISE_DEMAND_PATH_MANDATORY',
        clean_parent=PARENT,build_only=True,game_started=False)


def job_class(native, Parent):
    class CoherenceJob(Parent):
        def preflight(self):
            super().preflight()
            self.parent_manifest=verify_parent(self,native)
            print('COHERENCE_PARENT_VERIFIED='+PARENT,flush=True)

        def prepare(self):
            # Do not replay or re-edit earlier patch packages.
            updates={p:patch.transform(p,self.git('show',PARENT+':'+p)) for p in patch.EXPECTED}
            install_delta(self,native,self.parent_manifest,updates)
            self.command([sys.executable,'-B',PACKAGE/'verify_coherence.py',
                          '--compiler',self.compiler,'--output',self.run/'coherence-policy-tests'],capture=False)
            print('AUTOMATIC_COHERENCE_SOURCE_READY=YES; SHADER_CHANGES=NONE',flush=True)

        def verify_native_library(self):
            artifacts=self.run/'native-tests'
            if artifacts.is_symlink() or (artifacts.exists() and not artifacts.is_dir()):
                raise RuntimeError('UNSAFE_NATIVE_TEST_DIRECTORY')
            artifacts.mkdir(exist_ok=True)
            # Verify all three compiled source files, not just matching fragments.
            for name in patch.EXPECTED:
                expected=patch.transform(name,self.git('show',PARENT+':'+name))
                if (self.source/name).read_bytes()!=expected:raise RuntimeError('COMPILED_POLICY_DIFFERS='+name)
            result=self.command([sys.executable,'-B',PACKAGE/'verify_coherence.py',
                    '--compiler',self.compiler,'--output',self.run/'coherence-native-tests','--source',self.source])
            with (self.info/'native-tests.log').open('ab') as out:out.write(result)
            self.report['automatic_coherence_policy_tests']='PASS_EXTRACTED_PRODUCTION_WITH_EXPLICIT_STUBS'
            super().verify_native_library()
            self.command(['nice','-n','10','ninja','-C',self.build,'-j','2',
                 'CMakeFiles/shadps4.dir/src/video_core/page_manager.cpp.o',
                 'CMakeFiles/shadps4.dir/src/emulator.cpp.o'],capture=False)

        def finish(self,code):
            try:
                for name in ('coherence-policy-tests','coherence-native-tests'):
                    path=self.run/name/'verification.log'
                    if path.is_file():(self.info/(name+'.log')).write_bytes(path.read_bytes())
            except (OSError,ValueError) as error:
                self.report['coherence_log_collection_error']=str(error);code=max(code,2)
            return super().finish(code)
    return CoherenceJob


def main():
    if any(x!='--build-only' for x in sys.argv[1:]):raise RuntimeError('THIS_STAGE_IS_BUILD_ONLY_NO_GAME_LAUNCH')
    verify_package(PACKAGE)
    root=Path.home()/'projects/shadps4'
    previous=root/'scripts'/('typed-float-atomic-'+ATOMIC+'.py')
    if digest(previous)!=ATOMIC_SHA:raise RuntimeError('VERIFIED_BUILD_WORKFLOW_CHANGED')
    spec=importlib.util.spec_from_file_location('coherence_existing_atomic_workflow',previous)
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    original=module.job_class
    module.job_class=lambda native,parent,validator:job_class(native,original(native,parent,validator))
    sys.argv=[sys.argv[0],'--build-only']
    return module.main()

if __name__=='__main__':
    try:raise SystemExit(main())
    except (OSError,RuntimeError,ValueError,subprocess.CalledProcessError) as error:
        print('AUTOMATIC_COHERENCE_PREFLIGHT_FAILED='+str(error),file=sys.stderr,flush=True)
        logs=Path.home()/'projects/shadps4/logs';logs.mkdir(parents=True,exist_ok=True)
        folder=Path(tempfile.mkdtemp(prefix='automatic-coherence-preflight-',dir=logs))
        (folder/'error.txt').write_text(str(error)+'\nGAME_LAUNCHED=NO\n')
        archive=folder.with_suffix('.tar.gz')
        with tarfile.open(archive,'w:gz') as out:out.add(folder/'error.txt',arcname='info/error.txt')
        print('UPLOAD_THIS='+str(archive),flush=True)
        raise SystemExit(2)
