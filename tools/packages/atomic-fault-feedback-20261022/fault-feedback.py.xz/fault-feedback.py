#!/usr/bin/env python3
"""Preserve concurrent page-fault bits and collect compiler artifacts in isolation.

Extends the exact host-built implicit-dependency candidate. No title/hash
selection, driver override, guest-read substitution or rendering preset.
"""
from __future__ import annotations
import argparse
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

PARENT = 'e314b11ba791669aed4755bd443ce98675db0404'
PARENT_TREE = 'c347c62e06147159bba26a8c21904de61186ac21'
PARENT_BINARY = 'd0b169e6af812243366676022dba4ed66879941ac7c680d2fc153b87c62830e2'
PREVIOUS_REV = '0bde46afaa33b29051b9d8a2c1b31f9c0f6876d6'
PREVIOUS_SHA = '8d16c48766320883fe34664c066229a02a144389d067ffafaffe292c2c6f607e'
CONTEXT = 'src/shader_recompiler/backend/spirv/spirv_emit_context.cpp'
FAULT = 'src/video_core/buffer_cache/fault_manager.cpp'
CACHE = 'src/video_core/renderer_vulkan/vk_pipeline_serialization.cpp'
PARSER = 'src/video_core/host_shaders/fault_buffer_process.comp'
EXPECTED = {
    CONTEXT: 'ececaf8e8110ce69a6dab7369d1e548010887949',
    FAULT: 'e7b3adba3e4874c2fc9e091a04fba56081ad716c',
    CACHE: '61856e94c02824a616153ab4f1d02949856e605e',
    PARSER: '1a5f982d3f6118265e3eae92e5ba88a64f9d7a89',
}
OLD_RECORD = '''    const auto fault_value{OpLoad(U32[1], fault_ptr)};
    const auto fault_value_masked{OpBitwiseOr(U32[1], fault_value, page_mask)};
    OpStore(fault_ptr, fault_value_masked);'''
NEW_RECORD = '''    OpAtomicOr(U32[1], fault_ptr, ConstU32(static_cast<u32>(spv::Scope::Device)),
               u32_zero_value, page_mask);'''


def sha(data):
    return hashlib.sha256(data).hexdigest()


def blob(data):
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()


def once(text, old, new):
    if text.count(old) != 1:
        raise RuntimeError('FAULT_SOURCE_ANCHOR_NOT_UNIQUE='+repr(old[:100]))
    return text.replace(old, new, 1)


def function(text, anchor):
    if text.count(anchor) != 1:
        raise RuntimeError('FAULT_FUNCTION_NOT_UNIQUE='+anchor)
    begin=text.index(anchor); start=text.index('{',begin); depth=0
    for end in range(start,len(text)):
        if text[end]=='{': depth+=1
        elif text[end]=='}':
            depth-=1
            if depth==0: return text[begin:end+1]
    raise RuntimeError('FAULT_FUNCTION_UNBALANCED')


PARSER_MAIN = 'void main() {\n    const uint id = gl_GlobalInvocationID.x;\n    uint word = atomicOr(fault_buffer[id], 0u);\n    if (word == 0u || MAX_PAGE_FAULTS <= 1u) {\n        return;\n    }\n    const uint requested = uint(bitCount(word));\n    uint first = atomicAdd(download_buffer32[0], 0u);\n    uint reserved;\n    for (;;) {\n        if (first >= MAX_PAGE_FAULTS - 1u) {\n            return;\n        }\n        reserved = min(requested, MAX_PAGE_FAULTS - 1u - first);\n        const uint observed = atomicCompSwap(download_buffer32[0], first, first + reserved);\n        if (observed == first) {\n            break;\n        }\n        first = observed;\n    }\n    uint processed = 0u;\n    for (uint index = 0u; index < reserved; ++index) {\n        const uint bit = uint(findLSB(word));\n        word &= word - 1u;\n        processed |= 1u << bit;\n        const uint page = id * 32u + bit;\n        download_buffer[first + index + 1u] = uint64_t(page) << CACHING_PAGEBITS;\n    }\n    atomicAnd(fault_buffer[id], ~processed);\n}'


def transform(name, text):
    if name == CONTEXT:
        body=function(text,'Id EmitContext::DefineGetBdaPointer()')
        return once(text,body,once(body,OLD_RECORD,NEW_RECORD))
    if name == PARSER:
        return once(text, function(text, 'void main()'), PARSER_MAIN)
    if name == FAULT:
        initialization = '''    scheduler.EndRendering();
    const auto cmdbuf = scheduler.CommandBuffer();
    cmdbuf.fillBuffer(fault_buffer.Handle(), 0, fault_buffer_size, 0u);
    const vk::BufferMemoryBarrier2 initialized = {
        .srcStageMask = vk::PipelineStageFlagBits2::eClear,
        .srcAccessMask = vk::AccessFlagBits2::eTransferWrite,
        .dstStageMask = vk::PipelineStageFlagBits2::eAllCommands,
        .dstAccessMask = vk::AccessFlagBits2::eShaderRead | vk::AccessFlagBits2::eShaderWrite,
        .srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED,
        .dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED,
        .buffer = fault_buffer.Handle(),
        .offset = 0,
        .size = fault_buffer_size,
    };
    cmdbuf.pipelineBarrier2(vk::DependencyInfo{
        .bufferMemoryBarrierCount = 1u,
        .pBufferMemoryBarriers = &initialized,
    });

'''
        text=once(text, '    device.destroyShaderModule(module);',
                  initialization+'    device.destroyShaderModule(module);')
        text=once(text, '    std::memset(mapped, 0, PageFaultAreaSize);',
                  '    std::memset(mapped, 0, PageFaultAreaSize);\n'
                  '    download_buffer.Flush(offset, PageFaultAreaSize);')
        text=once(text, '    scheduler.DeferOperation([this, mapped, area = current_area] {',
                  '    scheduler.DeferOperation([this, mapped, offset, area = current_area] {\n'
                  '        download_buffer.Invalidate(offset, PageFaultAreaSize);')
        text=once(text, '        const u32 fault_count = fault_buf[0];',
                  '        ASSERT_MSG(fault_buf[0] < MaxPageFaults, "Fault feedback count {} exceeds capacity",\n'
                  '                   fault_buf[0]);\n'
                  '        const u32 fault_count = static_cast<u32>(fault_buf[0]);')
        text=once(text, '            (void)buffer_cache.ObtainBuffer(start, end - start);',
                  '            (void)buffer_cache.ObtainBuffer(start, end - start,\n'
                  '                                             ObtainBufferFlags::IgnoreStreamBuffer);')
        for stage in ('eComputeShader','eAllCommands'):
            access='eShaderRead' if stage=='eComputeShader' else 'eShaderWrite'
            old=('        .dstStageMask = vk::PipelineStageFlagBits2::'+stage+',\n'
                 '        .dstAccessMask = vk::AccessFlagBits2::'+access+',\n'
                 '        .buffer = fault_buffer.Handle(),')
            new=('        .dstStageMask = vk::PipelineStageFlagBits2::'+stage+',\n'
                 '        .dstAccessMask = vk::AccessFlagBits2::eShaderRead |\n'
                 '                         vk::AccessFlagBits2::eShaderWrite,\n'
                 '        .buffer = fault_buffer.Handle(),')
            text=once(text,old,new)
        post_call = '''    cmdbuf.pipelineBarrier2(vk::DependencyInfo{
        .dependencyFlags = vk::DependencyFlagBits::eByRegion,
        .bufferMemoryBarrierCount = 1,
        .pBufferMemoryBarriers = &post_barrier,
    });'''
        handoff = '''    const std::array<vk::BufferMemoryBarrier2, 2> completed = {{
        post_barrier,
        {
            .srcStageMask = vk::PipelineStageFlagBits2::eComputeShader,
            .srcAccessMask = vk::AccessFlagBits2::eShaderWrite,
            .dstStageMask = vk::PipelineStageFlagBits2::eHost,
            .dstAccessMask = vk::AccessFlagBits2::eHostRead,
            .srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED,
            .dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED,
            .buffer = download_buffer.Handle(),
            .offset = offset,
            .size = PageFaultAreaSize,
        },
    }};
    cmdbuf.pipelineBarrier2(vk::DependencyInfo{
        .bufferMemoryBarrierCount = static_cast<u32>(completed.size()),
        .pBufferMemoryBarriers = completed.data(),
    });'''
        text=once(text,post_call,handoff)
        return text
    if name == CACHE:
        for version in ('ShaderBinaryVersion','ShaderMetaVersion'):
            text=once(text,version+' = 0x43520006u;',version+' = 0x43520007u;')
        return text
    raise RuntimeError('UNEXPECTED_FAULT_PATH='+name)


# A numerical adapter executes the EXACT generated record sequence. Atomic
# load/store in the old adapter avoid C++ UB while reproducing a legal lost
# update schedule; this is not a GPU test or a shader interpreter.
NUMERIC_CPP = r'''#include <array>
#include <atomic>
#include <barrier>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <thread>
#include <vector>
using u32=std::uint32_t; using Id=u32;
namespace spv {enum class Scope:u32 {Device=1};}
struct Emitter {
 std::array<Id,2> U32{0,32}; Id u32_zero_value=0;
 std::barrier<>* rendezvous{};
 Id ConstU32(u32 v){return v;}
 Id OpLoad(Id,std::atomic<u32>* p){auto value=p->load(std::memory_order_relaxed);if(rendezvous)rendezvous->arrive_and_wait();return value;}
 Id OpBitwiseOr(Id,Id a,Id b){return a|b;}
 void OpStore(std::atomic<u32>* p,Id v){p->store(v,std::memory_order_relaxed);}
 Id OpAtomicOr(Id type,std::atomic<u32>* p,Id scope,Id semantics,Id value){
  if(type!=32 || scope!=1 || semantics!=0)throw std::runtime_error("WRONG_ATOMIC_TYPE_SCOPE_OR_SEMANTICS");
  return p->fetch_or(value,std::memory_order_relaxed);
 }
 void record(std::atomic<u32>* fault_ptr,Id page_mask){
__RECORD__
 }
};
int main(){
 try {
  std::atomic<u32> lost{0};std::barrier rendezvous(2);Emitter racing;racing.rendezvous=&rendezvous;
  std::jthread a([&]{racing.record(&lost,1);}),b([&]{racing.record(&lost,2);});a.join();b.join();
  if(lost.load()!=3)throw std::runtime_error("LOST_CONCURRENT_FAULT_BIT");
  Emitter e; unsigned pairs=0;
  for(unsigned first=0;first<32;++first)for(unsigned second=0;second<32;++second){
   std::atomic<u32> v{0x80000000u};e.record(&v,1u<<first);e.record(&v,1u<<second);
   if(v.load()!=(0x80000000u|(1u<<first)|(1u<<second)))throw std::runtime_error("BIT_OR_SEMANTICS");
   ++pairs;
  }
  std::array<std::atomic<u32>,257> words{};
  std::vector<std::jthread> threads;
  for(unsigned worker=0;worker<8;++worker)threads.emplace_back([&,worker]{
   Emitter worker_emitter;
   for(unsigned round=0;round<32;++round)for(unsigned w=0;w<words.size();++w)
    for(unsigned bit=worker;bit<32;bit+=8)worker_emitter.record(&words[w],1u<<bit);
  });
  for(auto& t:threads)t.join();
  for(auto& w:words)if(w.load()!=~u32{0})throw std::runtime_error("CONCURRENT_BITMAP_INCOMPLETE");
  std::cout<<"FAULT_ATOMIC_RECORD=PASS exact_emitted_sequence=YES bit_pairs="<<pairs
           <<" concurrent_words=257 workers=8 updates=263168 scope=DEVICE semantics=RELAXED\n";
  return 0;
 } catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 2;}
}
'''


QUEUE_CPP = '#include <algorithm>\n#include <array>\n#include <atomic>\n#include <bit>\n#include <cstdint>\n#include <iostream>\n#include <limits>\n#include <stdexcept>\n#include <thread>\n#include <vector>\nusing uint=std::uint32_t;using uint64_t=std::uint64_t;\nuint atomicOr(std::atomic<uint>& a,uint b){return a.fetch_or(b);}\nuint atomicAnd(std::atomic<uint>& a,uint b){return a.fetch_and(b);}\nuint atomicAdd(std::atomic<uint>& a,uint b){return a.fetch_add(b);}\nuint atomicCompSwap(std::atomic<uint>& a,uint before,uint after){a.compare_exchange_strong(before,after);return before;}\nint findLSB(uint word){return std::countr_zero(word);}\nint bitCount(uint word){return std::popcount(word);}\nuint min(uint a,uint b){return std::min(a,b);}\nstruct Queue {\n std::vector<std::atomic<uint>> words;\n std::array<std::atomic<uint>,2> counter{};\n std::vector<uint64_t> entries;\n explicit Queue(uint size,uint capacity):words(size),entries(capacity){}\n};\nstruct Invocation {\n const uint CACHING_PAGEBITS=14,MAX_PAGE_FAULTS;\n struct {uint x;}gl_GlobalInvocationID;\n std::vector<std::atomic<uint>>& fault_buffer;\n std::array<std::atomic<uint>,2>& download_buffer32;\n std::vector<uint64_t>& download_buffer;\n Invocation(Queue& queue,uint id,uint capacity):MAX_PAGE_FAULTS(capacity),gl_GlobalInvocationID{id},\n  fault_buffer(queue.words),download_buffer32(queue.counter),download_buffer(queue.entries){}\n __MAIN__\n};\nvoid check(bool ok,const char* why){if(!ok)throw std::runtime_error(why);}\nunsigned run_case(uint capacity,uint word_count,bool sparse){\n Queue q(word_count,capacity);\n std::vector<bool> expected(word_count*32),seen(word_count*32);\n unsigned expected_count=0,consumed=0,rounds=0;\n for(uint word=0;word<word_count;++word){\n  uint mask=sparse?(0x80010001u^(1u<<(word%31))):~uint{0};q.words[word].store(mask);\n  for(uint bit=0;bit<32;++bit)if(mask&(1u<<bit)){expected[word*32+bit]=true;++expected_count;}\n }\n while(consumed<expected_count){\n  check(rounds++<=expected_count,"QUEUE_DID_NOT_DRAIN");q.counter[0].store(0);q.counter[1].store(0);\n  std::fill(q.entries.begin(),q.entries.end(),~uint64_t{0});\n  std::vector<std::jthread> workers;\n  for(uint worker=0;worker<8;++worker)workers.emplace_back([&,worker]{\n   for(uint id=worker;id<word_count;id+=8){Invocation invocation(q,id,capacity);invocation.scan();}\n  });\n  for(auto& worker:workers)worker.join();\n  const uint count=q.counter[0].load();\n  check(count<capacity,"FAULT_QUEUE_COUNTER_EXCEEDS_CAPACITY");\n  check(count>0,"PENDING_FAULTS_DISCARDED");\n  check(q.entries[0]==~uint64_t{0},"COUNTER_SLOT_OVERWRITTEN_BY_PAGE");\n  for(uint index=1;index<=count;++index){\n   const uint64_t address=q.entries[index];\n   check((address&((1u<<14)-1))==0,"MISALIGNED_PAGE_ADDRESS");\n   const uint64_t page=address>>14;\n   check(page<expected.size()&&expected[page]&&!seen[page],"DUPLICATE_OR_INVALID_PAGE");\n   seen[page]=true;++consumed;\n  }\n  unsigned remaining=0;\n  for(auto& word:q.words)remaining+=std::popcount(word.load());\n  check(remaining+consumed==expected_count,"UNQUEUED_FAULT_BITS_LOST");\n }\n check(seen==expected,"MISSING_FINAL_PAGE_REPORT");return consumed;\n}\nint main(){\n try {\n  unsigned pages=0,cases=0;\n  for(uint capacity:{8u,1024u})for(bool sparse:{false,true})for(uint words:{1u,12u,32u}){\n   pages+=run_case(capacity,words,sparse);++cases;\n  }\n  Queue empty(4,8);Invocation no_fault(empty,0,8);no_fault.scan();check(empty.counter[0]==0,"EMPTY_QUEUE_CHANGED");\n  Queue full(2,8);full.counter[0]=7;full.words[1]=0x80000003u;Invocation no_space(full,1,8);no_space.scan();\n  check(full.counter[0]==7&&full.words[1]==0x80000003u,"FULL_QUEUE_DROPPED_REQUESTS");\n  std::cout<<"FAULT_QUEUE_DRAIN=PASS exact_shader_body=YES cases="<<cases<<" delivered_pages="<<pages\n           <<" capacity_1024_includes_header=YES overflow_retained=YES concurrent_reservation=YES\\n";\n  return 0;\n }catch(const std::exception& e){std::cerr<<e.what()<<\'\\n\';return 2;}\n}\n'


def compile_checks(job):
    folder=job.run/'native-tests'; folder.mkdir(exist_ok=True)
    results=[]
    for label,record in (('before',OLD_RECORD),('after',NEW_RECORD)):
        cpp=folder/('fault-record-'+label+'.cpp'); exe=cpp.with_suffix('')
        cpp.write_text(NUMERIC_CPP.replace('__RECORD__',record))
        job.command([job.compiler,'-std=c++23','-O2','-Wall','-Wextra','-Werror','-pthread',cpp,'-o',exe],capture=False)
        if label=='before':
            result=subprocess.run([str(exe)],capture_output=True,timeout=30)
            (job.info/'fault-record-negative.log').write_bytes(result.stdout+result.stderr)
            if result.returncode!=2 or b'LOST_CONCURRENT_FAULT_BIT' not in result.stderr:
                raise RuntimeError('OLD_FAULT_RACE_NOT_REPRODUCED')
            results.append(b'OLD_FAULT_NEGATIVE_CONTROL=PASS two_reports_lost_one_bit=YES\n')
        else: results.append(job.command([exe]))
    out=b''.join(results)
    with (job.info/'native-tests.log').open('ab') as stream: stream.write(out)
    print(out.decode(),end='',flush=True)


def check_queue(job, before, after):
    folder=job.run/'native-tests';folder.mkdir(exist_ok=True)
    results=[]
    for label,source in (('before',before),('after',after)):
        body=function(source,'void main()').replace('void main()', 'void scan()', 1)
        cpp=folder/('fault-queue-'+label+'.cpp');exe=cpp.with_suffix('')
        cpp.write_text(QUEUE_CPP.replace('__MAIN__',body))
        job.command([job.compiler,'-std=c++23','-O2','-Wall','-Wextra','-Werror','-pthread',cpp,'-o',exe],capture=False)
        if label=='before':
            result=subprocess.run([str(exe)],capture_output=True,timeout=30)
            (job.info/'fault-queue-negative.log').write_bytes(result.stdout+result.stderr)
            if result.returncode!=2 or b'FAULT_QUEUE_COUNTER_EXCEEDS_CAPACITY' not in result.stderr:
                raise RuntimeError('OLD_FAULT_QUEUE_OVERFLOW_NOT_REPRODUCED')
            results.append(b'OLD_QUEUE_NEGATIVE_CONTROL=PASS counter_overflow_and_dropped_pending_faults=REPRODUCED\n')
        else:results.append(job.command([exe]))
    output=b''.join(results)
    with (job.info/'native-tests.log').open('ab') as stream:stream.write(output)
    print(output.decode(),end='',flush=True)


# Use the complete production function body, not a second hand-written
# implementation. This fixture declares storage buffers and links real Sirit.
SIRIT_PREFIX = r'''#include <sirit/sirit.h>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <unordered_map>
#include <utility>
using u32=std::uint32_t;using u64=std::uint64_t;using Id=Sirit::Id;
enum class PointerType{U32,U64};
struct Binding{Id object,pointer;std::pair<Id,Id> Alias(PointerType)const{return {object,pointer};}};
struct EmitContext:Sirit::Module {
 struct {unsigned sparse_page_shift=14;} profile;
 std::array<Id,2> U32{},U1{};Id U64{},u32_zero_value{},u32_one_value{},u64_zero_value{};
 std::array<Binding,2> buffers{};unsigned bda_pagetable_index=0,fault_buffer_index=1;
 EmitContext():Sirit::Module(0x00010600u){
  AddCapability(spv::Capability::Shader);AddCapability(spv::Capability::Int64);
  SetMemoryModel(spv::AddressingModel::Logical,spv::MemoryModel::GLSL450);
  U32[1]=TypeUInt(32);U1[1]=TypeBool();U64=TypeUInt(64);
  u32_zero_value=ConstU32(0);u32_one_value=ConstU32(1);u64_zero_value=Constant(U64,u64{0});
  for(unsigned binding=0;binding<2;++binding){
   Id scalar=binding?U32[1]:U64;Id array=TypeRuntimeArray(scalar);
   Decorate(array,spv::Decoration::ArrayStride,binding?4u:8u);
   Id block=TypeStruct(array);Decorate(block,spv::Decoration::Block);MemberDecorate(block,0,spv::Decoration::Offset,0u);
   Id variable=AddGlobalVariable(TypePointer(spv::StorageClass::StorageBuffer,block),spv::StorageClass::StorageBuffer);
   Decorate(variable,spv::Decoration::DescriptorSet,0u);Decorate(variable,spv::Decoration::Binding,binding);
   buffers[binding]={variable,TypePointer(spv::StorageClass::StorageBuffer,scalar)};
  }
 }
 Id ConstU32(u32 value){return Constant(U32[1],value);}
 Id DefineGetBdaPointer();
};
'''
SIRIT_SUFFIX = r'''
int main(int argc,char** argv){
 try {
  if(argc!=2)throw std::runtime_error("EXPECTED_OUTPUT_PATH");
  EmitContext c;
  Id helper=c.DefineGetBdaPointer();
  Id void_type=c.TypeVoid();Id main=c.OpFunction(void_type,spv::FunctionControlMask::MaskNone,c.TypeFunction(void_type));
  c.AddEntryPoint(spv::ExecutionModel::GLCompute,main,"main",c.buffers[0].object,c.buffers[1].object);
  c.AddExecutionMode(main,spv::ExecutionMode::LocalSize,1u,1u,1u);c.AddLabel();
  c.OpFunctionCall(c.U64,helper,c.u64_zero_value);c.OpReturn();c.OpFunctionEnd();
  auto words=c.Assemble();if(words.size()<5||words[0]!=0x07230203u)throw std::runtime_error("INVALID_SPIRV");
  std::unordered_map<u32,u32> constants;unsigned atomics=0,plain_stores=0;bool in_helper=false;
  u32 scope_id=0,semantics_id=0;
  for(std::size_t i=5;i<words.size();){
   const u32 count=words[i]>>16,opcode=words[i]&0xffffu;
   if(!count||i+count>words.size())throw std::runtime_error("BAD_INSTRUCTION_LENGTH");
   if(opcode==static_cast<u32>(spv::Op::OpConstant)&&count==4)constants[words[i+2]]=words[i+3];
   if(opcode==static_cast<u32>(spv::Op::OpFunction))in_helper=words[i+2]==helper.value;
   if(in_helper&&opcode==static_cast<u32>(spv::Op::OpAtomicOr)){
    if(count!=7||words[i+1]!=c.U32[1].value)throw std::runtime_error("WRONG_ATOMIC_ENCODING");
    ++atomics;scope_id=words[i+4];semantics_id=words[i+5];
   }
   if(in_helper&&opcode==static_cast<u32>(spv::Op::OpStore))++plain_stores;
   if(opcode==static_cast<u32>(spv::Op::OpFunctionEnd))in_helper=false;
   i+=count;
  }
  if(atomics!=1||plain_stores!=0||!constants.contains(scope_id)||!constants.contains(semantics_id)||
     constants.at(scope_id)!=1||constants.at(semantics_id)!=0)throw std::runtime_error("FAULT_ATOMIC_CONTRACT_FAILED");
  std::ofstream out(argv[1],std::ios::binary);out.write(reinterpret_cast<const char*>(words.data()),static_cast<std::streamsize>(words.size()*sizeof(u32)));
  if(!out)throw std::runtime_error("SPIRV_WRITE_FAILED");
  std::cout<<"PINNED_SIRIT_FAULT_FUNCTION=PASS whole_production_function=YES atomic_or=1 plain_stores=0 scope=DEVICE semantics=RELAXED\n";
  return 0;
 }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 2;}
}
'''


def verify_sirit(job, text):
    folder=job.run/'native-tests';folder.mkdir(exist_ok=True)
    cpp=folder/'real-sirit-fault.cpp'; exe=folder/'real-sirit-fault';out=folder/'real-sirit-fault.spv'
    cpp.write_text(SIRIT_PREFIX+function(text,'Id EmitContext::DefineGetBdaPointer()')+SIRIT_SUFFIX)
    libraries=list((job.build/'externals/sirit').rglob('libsirit.a'))
    headers=sorted((job.source/'externals').rglob('spirv/unified1/spirv.hpp11'))
    if len(libraries)!=1 or not headers: raise RuntimeError('FAULT_NATIVE_SIRIT_DEPENDENCY_MISSING')
    header=headers[0]
    job.command([job.compiler,'-std=c++23','-O2','-Wall','-Wextra','-Werror',
                 '-I'+str(job.sirit/'include'),'-I'+str(header.parents[2]),cpp,libraries[0],'-o',exe],capture=False)
    result=job.command([exe,out])
    with (job.info/'native-tests.log').open('ab') as stream:stream.write(result)
    print(result.decode(),end='',flush=True)
    validator=shutil.which('spirv-val')
    if validator:
        job.command([validator,'--target-env','vulkan1.3',out],capture=False)
        job.report['fault_spirv_validation']='PASS'
    else:job.report['fault_spirv_validation']='NOT_RUN_TOOL_NOT_INSTALLED'
    shutil.copyfile(out,job.info/'native-fault-emitter.spv')
    job.report['real_sirit_fault_emitter']='COMPILED_LINKED_ASSEMBLED'


def install_delta(job,native,updates):
    base=native.base
    for ref in (job.revision,PARENT):
        if job.git('rev-parse',ref+'^{tree}').decode().strip()!=PARENT_TREE:
            raise RuntimeError('LATEST_IMPLICIT_MEMORY_TREE_MISMATCH')
    mpath=job.info/'correction.json';manifest=json.loads(mpath.read_text())
    expected=set(manifest['files'])|set(updates)
    env=dict(base.ENV,GIT_INDEX_FILE=str(job.run/'fault-feedback-index'))
    job.git('read-tree',PARENT,env=env)
    for name,data in updates.items():
        oid=job.git('hash-object','-w','--stdin',input_data=data).decode().strip()
        if oid!=blob(data): raise RuntimeError('FAULT_OBJECT_MISMATCH')
        job.git('update-index','--add','--cacheinfo',f'100644,{oid},{name}',env=env)
        original=manifest['files'].get(name,{}).get('original_blob',EXPECTED[name])
        manifest['files'][name]={'original_blob':original,'corrected_blob':oid,'sha256':sha(data)}
    tree=job.git('write-tree',env=env).decode().strip()
    revision=job.git('commit-tree',tree,'-p',PARENT,input_data=(
        'Preserve and service bounded concurrent shader page-fault reports\n\n'
        'Use device-scoped 32-bit atomic fault-bit accumulation and include '
        'read/write access at parser boundaries. Preserve overflow bits, initialize and flush '
        'feedback memory, and make requested pages resident. Invalidate shader caches. '
        'No title/hash selectors, discarded faults or guest-read substitution.\n').encode()).decode().strip()
    if set(job.git('diff','--name-only',PARENT,revision).decode().splitlines())!=set(updates):
        raise RuntimeError('FAULT_INCREMENTAL_CHANGE_SET_MISMATCH')
    if set(job.git('diff','--name-only',base.BASE,revision).decode().splitlines())!=expected:
        raise RuntimeError('FAULT_COMPLETE_CHANGE_SET_MISMATCH')
    diff=job.git('diff',PARENT,revision,'--',*updates)
    (job.info/'fault-feedback.patch').write_bytes(diff)
    with (job.info/'correction.patch').open('ab') as stream:stream.write(b'\n# Atomic fault feedback correction\n'+diff)
    manifest['parent']=PARENT
    manifest['fault_feedback']={'parent_tree':PARENT_TREE,'runner_sha256':sha(Path(__file__).read_bytes()),
        'incremental_files':sorted(updates),'atomic_scope':'Device','atomic_semantics':'Relaxed',
        'zero_on_missing_page_policy_changed':False,'fault_recovery_requires_resident_arena':True,
        'hang_cause_proven':False}
    base.write_json(mpath,manifest)
    for name,data in updates.items():
        path=job.stage/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
    job.git('update-ref','refs/heads/local/atomic-fault-feedback-'+revision[:12],revision)
    job.revision=revision
    job.report.update(revision=revision,tree=tree,source_parent=PARENT,manifest_sha256=base.digest(mpath),
                      fault_feedback='ATOMIC_BOUNDED_LOSSLESS_FEEDBACK_AND_RESIDENT_RECOVERY')
    print('FAULT_FEEDBACK_CORRECTION=APPLIED files=4 overflow_bits_preserved=YES fault_pages_resident=YES',flush=True)


# This is CPU-side compiler output, not a render-state modification or driver
# override. All filenames are collected without title or shader selection.
CAPTURE_METHOD = r'''    def collect_compiler_artifacts(self):
        import stat
        source=self.run/"profile/user/shader/dumps"
        destination=self.run/"info/compiler-artifacts"
        destination.mkdir(exist_ok=True)
        budget=48*1024*1024; single_limit=4*1024*1024
        entries=[]; total=0; spv_count=0; binary_count=0; inventory_omitted=0
        if source.exists() and (source.is_symlink() or not source.is_dir()):
            raise RuntimeError("INVALID_SHADER_DUMP_DIRECTORY")
        paths=sorted(source.rglob("*")) if source.is_dir() else []
        def priority(path):
            return (0 if path.suffix in (".spv",".bin") else
                    1 if path.name.endswith(".irprogram.txt") and ".pre-" not in path.name else 2,
                    str(path))
        for path in sorted(paths,key=priority):
            relative=path.relative_to(source)
            record={"path":str(relative)}
            try:
                mode=path.lstat().st_mode
                if stat.S_ISDIR(mode): continue
                if not stat.S_ISREG(mode) or not path.resolve().is_relative_to(source.resolve()):
                    raise ValueError("NOT_A_REGULAR_CONTAINED_FILE")
                if any(parent.is_symlink() for parent in path.parents if parent!=source.parent):
                    raise ValueError("SYMLINK_IN_DUMP_PATH")
                size=path.stat().st_size;record["bytes"]=size
                if len(entries)>=8192:
                    inventory_omitted+=1
                    continue
                if size>single_limit or total+size>budget:
                    record["status"]="RETAINED_ON_SERVER_BUDGET_LIMIT"
                else:
                    with path.open("rb") as stream: data=stream.read(single_limit+1)
                    if len(data)!=size: raise ValueError("FILE_CHANGED_DURING_COLLECTION")
                    target=destination/relative;target.parent.mkdir(parents=True,exist_ok=True)
                    target.write_bytes(data);total+=len(data)
                    record.update(status="COPIED",sha256=hashlib.sha256(data).hexdigest())
                    spv_count+=path.suffix==".spv";binary_count+=path.suffix==".bin"
            except (OSError,ValueError) as error:
                record.update(status="UNREADABLE_OR_UNSAFE",error=str(error))
            entries.append(record)
        complete=bool(spv_count) and inventory_omitted==0 and all(e["status"]=="COPIED" for e in entries)
        result={"policy":"all shaders; SPIR-V and original binaries first; no GPU readback",
                "source":str(source),"bytes_copied":total,"budget_bytes":budget,
                "spirv_files":spv_count,"original_binaries":binary_count,
                "inventory_entries_omitted":inventory_omitted,
                "coverage":"COMPLETE_RECORDED_FILE_SET" if complete else "INCOMPLETE",
                "bound_shader_at_hang_identified":False,"files":entries}
        (self.run/"info/compiler-artifacts-manifest.json").write_text(json.dumps(result,indent=2)+"\n")
        self.meta.update(COMPILER_ARTIFACTS=result["coverage"],COMPILER_SPIRV_FILES=str(spv_count),
                         COMPILER_CAPTURE_BYTES=str(total),GPU_READBACK_CAPTURE="DISABLED")
        if self.meta.get("GAME_LAUNCHED")=="YES" and spv_count==0:
            raise RuntimeError("NO_COMPILED_SHADER_ARTIFACTS_COLLECTED")

'''
CAPTURE_LIMIT = r'''        if elapsed >= getattr(self, "next_compiler_size_check", 0):
            self.next_compiler_size_check=elapsed+10
            folder=self.run/"profile/user/shader/dumps"
            total=sum(p.stat().st_size for p in folder.rglob("*") if p.is_file() and not p.is_symlink()) if folder.is_dir() else 0
            if total>256*1024*1024:
                self.meta["STOP_REASON"]="COMPILER_DUMP_DISK_BUDGET"
                raise RuntimeError("COMPILER_DUMP_DISK_BUDGET_STOP_OWNED_TEST")
'''


def capture_runtime(text, adapter):
    text=once(text,'data["GPU"].update(patch_shaders=False,dump_shaders=False)',
              'data["GPU"].update(patch_shaders=False,dump_shaders=True)')
    text=once(text, '        self.meta.update(PROFILE_PATH=str(destination),',
              '        self.meta["COMPILER_DIAGNOSTICS"]="ISOLATED_SHADER_DUMPS_ONLY"\n'
              '        self.meta["EXPENSIVE_DIAGNOSTICS"]="NO_GPU_READBACKS_OR_DRIVER_TRACING"\n'
              '        self.meta.update(PROFILE_PATH=str(destination),')
    # The collector runs after owned process shutdown and log-reader completion.
    original=adapter.NO_CAPTURE
    replacement=original.replace('"sirit-provenance.json","sirit-upstream.patch"',
        '"sirit-provenance.json","sirit-upstream.patch","native-fault-emitter.spv"')
    replacement+='        self.collect_compiler_artifacts()\n'
    text=adapter.replace_function(text,'collect_indirect_snapshot',replacement,True)
    text=once(text,'    def collect_indirect_snapshot(self):',CAPTURE_METHOD+'    def collect_indirect_snapshot(self):')
    text=once(text,'    def monitor_vram(self, elapsed, free):\n',
              '    def monitor_vram(self, elapsed, free):\n'+CAPTURE_LIMIT)
    ast.parse(text)
    if text.count('dump_shaders=True')!=1:raise RuntimeError('ISOLATED_DUMP_POLICY_NOT_UNIQUE')
    return text


def job_class(native,parent_job):
    class FaultJob(parent_job):
        def preflight(self):
            super().preflight()
            path=self.root/'logs/masked-wave-build-20261022-113337-36383/info/build-result.json'
            report=json.loads(path.read_bytes())
            binary=self.root/f'clean-rebase-verified/candidates/{PARENT}-{PARENT_BINARY}/shadps4'
            if (report.get('revision')!=PARENT or report.get('tree')!=PARENT_TREE or
                report.get('candidate_sha256')!=PARENT_BINARY or report.get('full_build')!='PASS' or
                not all(report.get(k) is True for k in ('source_restored','build_binary_restored','sirit_restored')) or
                native.base.digest(binary)!=PARENT_BINARY):
                raise RuntimeError('LATEST_IMPLICIT_MEMORY_HOST_BUILD_NOT_VERIFIED')
            (self.info/'previous-implicit-memory-build.json').write_bytes(path.read_bytes())
        def prepare(self):
            super().prepare()
            before={name:self.git('show',self.revision+':'+name) for name in EXPECTED}
            for name,data in before.items():
                if blob(data)!=EXPECTED[name]:raise RuntimeError('FAULT_PREIMAGE_MISMATCH='+name)
            after={name:transform(name,data.decode()).encode() for name,data in before.items()}
            print('CHECKING_CONCURRENT_FAULT_RECORDING',flush=True)
            compile_checks(self)
            check_queue(self,before[PARSER].decode(),after[PARSER].decode())
            install_delta(self,native,after)
        def verify_native_library(self):
            super().verify_native_library()
            verify_sirit(self,(self.source/CONTEXT).read_text())
            print('COMPILING_REAL_FAULT_QUEUE_SHADER',flush=True)
            self.command(['nice','-n','10','cmake','--build',self.build,
                          '--target','host_shaders','--parallel','2'],capture=False)
            self.report['fault_queue_shader']='NATIVE_GLSLANG_HOST_SHADERS_TARGET_PASS'
            print('COMPILING_REAL_FAULT_FEEDBACK_TRANSLATION_UNITS',flush=True)
            self.command(['nice','-n','10','ninja','-C',self.build,'-j','2',
                *['CMakeFiles/shadps4.dir/'+name+'.o' for name in EXPECTED if name.endswith('.cpp')]],capture=False)
    return FaultJob


def load_previous(root):
    path=root/'scripts'/('implicit-memory-dependencies-'+PREVIOUS_REV+'.py')
    if path.is_symlink() or not path.is_file() or sha(path.read_bytes())!=PREVIOUS_SHA:
        raise RuntimeError('VERIFIED_DEPENDENCY_RUNNER_MISSING_OR_CHANGED='+str(path))
    ast.parse(path.read_bytes(),filename=str(path))
    spec=importlib.util.spec_from_file_location('verified_dma_runner',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


def main():
    parser=argparse.ArgumentParser(add_help=False)
    parser.add_argument('--root',type=Path,default=Path.home()/'projects/shadps4')
    args,_=parser.parse_known_args()
    dma=load_previous(args.root)
    descriptor=dma.load_descriptor(args.root)
    fmt=descriptor.load_format(Path(descriptor.__file__).with_name('restore_ubnorm_nz_20261022.py'))
    native=fmt.load_native(args.root/'scripts'/('native-masked-minimum-'+descriptor.NATIVE_PACKAGE_REV))
    previous=dma.job_class(native,descriptor.job_class(native,fmt.job_class(native)))
    native.NativeJob=job_class(native,previous)
    original=native.base.adapter.prepare_runtime
    native.base.adapter.prepare_runtime=lambda data:capture_runtime(descriptor.harden_runtime(original(data)),native.base.adapter)
    return native.main()


if __name__=='__main__':
    try:raise SystemExit(main())
    except (RuntimeError,OSError,ValueError) as error:
        print('FAULT_FEEDBACK_ERROR='+str(error),file=sys.stderr);raise SystemExit(2)
