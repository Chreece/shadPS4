#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

P="$HOME/projects/shadps4/GhostOfTsushima"
TESTS="$P/tests"
LOGROOT="$HOME/projects/shadps4/logs"
V31="$TESTS/got-v31-nptoolkit-mspace-20261013"
V51="$TESTS/got-v51-stencil-reference-20261014"
V55="$TESTS/got-v55-empty-dynamic-slot-null-20261014"
V56="$TESTS/got-v56-late-dynamic-bindless-20261014"
RES='src/shader_recompiler/ir/passes/resource_patching_pass.cpp'
RAST='src/video_core/renderer_vulkan/vk_rasterizer.cpp'
SHA31='1e7264ec822d00060cddf9649fc704217524163e81673d87e5059e64e1375f6f'
RAST51='814677f63524610ba23932fd4ebbe062be299d641ac4699c390d62fe1cc1b03b'
DRV='87908e0c6833c0f6dc86cb079cb0f34de0dee7e970da89b5303f0e6b29e326f7'
DRIVER="$P/tools/radv-nuw-complete-25.0.7/libvulkan_radeon.so"
ICD="$P/tools/radv-nuw-complete-25.0.7/radeon_icd.json"
GAME='/mnt/roms-all/ps4-games/CUSA11456/eboot.bin'

sha(){ sha256sum "$1" | cut -d' ' -f1; }
fail(){ echo "STOP: $*" >&2; exit 2; }

[[ "$(id -u)" != 0 ]] || fail 'run without sudo'
if pgrep -u "$(id -u)" -x shadps4 >/dev/null; then fail 'another shadPS4 is running'; fi
[[ -x "$V31/build/shadps4" && "$(sha "$V31/build/shadps4")" == "$SHA31" ]] || fail 'v31 build baseline changed'
[[ -x "$V55/build/shadps4" && -f "$V55/$RES" ]] || fail 'v55 build/source missing'
[[ -f "$V51/$RAST" && "$(sha "$V51/$RAST")" == "$RAST51" ]] || fail 'v51 rasterizer source changed'
[[ -f "$DRIVER" && "$(sha "$DRIVER")" == "$DRV" && -f "$ICD" ]] || fail 'private RADV changed/missing'
[[ -f "$GAME" ]] || fail 'GoT eboot missing'
[[ -f "$V55/build/compile-argv.json" && -f "$V55/build/link-argv.json" && -f "$V51/build/compile-argv.json" ]] || fail 'stored build manifests missing'
mkdir -p "$V56/$(dirname "$RES")" "$V56/$(dirname "$RAST")" "$V56/build" "$P/play" "$LOGROOT"

python3 - "$V55/$RES" "$V56/$RES" "$V51/$RAST" "$V56/$RAST" <<'PY'
from pathlib import Path
import re,sys
res_src,res_dst,rast_src,rast_dst=map(Path,sys.argv[1:])

# Resource compile-time fix: v55 proved all 53 rows can be empty at shader compile
# time. Keep the dynamic array declaration anyway, using only a typed null image
# as the SPIR-V prototype. Actual descriptors are read on every BindTextures call.
r=res_src.read_text()
old='''        if (!prototype.has_value()) {\n            LOG_WARNING(Render_Recompiler,\n                        "GOT55_GHOST_EMPTY_DYNAMIC_SLOT shader={:#x} slot={} rows_scanned=53 action=null_sampled_image",\n                        info.pgm_hash, index->slot);\n        } else {\n            image_res.ghost_dynamic_image_count = 53;\n            image_res.ghost_dynamic_image_slot = index->slot;\n            image_res.ghost_prototype_image = *prototype;\n'''
new='''        if (!prototype.has_value()) {\n            // The descriptor table can be empty while this permutation is compiled and\n            // become populated later when gameplay starts. Preserve the 53-entry array\n            // shape; the null image supplies only sampled-image type information.\n            image_res.ghost_dynamic_image_count = 53;\n            image_res.ghost_dynamic_image_slot = index->slot;\n            image_res.ghost_prototype_image = AmdGpu::Image::Null(image_res.is_depth);\n            LOG_WARNING(Render_Recompiler,\n                        "GOT56_LATE_DYNAMIC_SLOT shader={:#x} slot={} rows_scanned=53 compile_prototype=typed_null runtime_binding=enabled",\n                        info.pgm_hash, index->slot);\n        } else {\n            image_res.ghost_dynamic_image_count = 53;\n            image_res.ghost_dynamic_image_slot = index->slot;\n            image_res.ghost_prototype_image = *prototype;\n'''
if r.count(old)!=1:
    raise SystemExit('STOP: v55 resource handoff block changed')
r=r.replace(old,new,1)
if r.count('GOT56_LATE_DYNAMIC_SLOT')!=1 or r.count('GOT53_NULL_INVALID_IMAGE')!=1:
    raise SystemExit('STOP: resource patch verification failed')
res_dst.parent.mkdir(parents=True,exist_ok=True)
if res_dst.exists() and res_dst.read_text()!=r: raise SystemExit('STOP: existing v56 resource source differs')
res_dst.write_text(r)

v=rast_src.read_text()
# If an older guard nulls an entire dynamic array solely because the compile-time
# prototype is null, remove that guard. Current-row validity is checked below.
guard=re.compile(r'''\n        if \(image_desc\.ghost_dynamic_image_count &&\n            \(!tsharp\.Valid\(\) \|\| tsharp\.Address\(\) == 0 \|\|\n             !memory->IsValidGpuMapping\(tsharp\.Address\(\), 0\)\)\) \{\n            // Do not read the indirect table or rebind a prototype that points\n            // at memory that is no longer resident\.\n            bind_null_image\(\);\n            continue;\n        \}\n''')
v,n=guard.subn('\n',v,count=1)
if n not in (0,1): raise SystemExit('STOP: unexpected dynamic prototype guard count')

# Runtime-row fallback must be allowed when the compile prototype is the typed
# null. Invalid rows stay null; valid later rows remain their real guest image.
old_assert='''                    ASSERT_MSG(tsharp.Valid() && tsharp.Address() != 0,\n                               "Ghost prototype descriptor is invalid");'''
new_assert='''                    if (tsharp.Address() == 0) {\n                        ghost_dynamic_images[row] = AmdGpu::Image::Null(image_desc.is_depth);\n                        continue;\n                    }\n                    ASSERT_MSG(tsharp.Valid(), "Ghost prototype descriptor is invalid");'''
if v.count(old_assert)!=1: raise SystemExit('STOP: Ghost runtime fallback assertion changed')
v=v.replace(old_assert,new_assert,1)

# Do not reject the whole 53-entry array just because the compile-only prototype
# has address zero. For fixed resources the old checks remain exact.
old1='''        if (tsharp.Address() == 0 || data_fmt == AmdGpu::DataFormat::FormatInvalid) {'''
new1='''        if (!image_desc.ghost_dynamic_image_count &&\n            (tsharp.Address() == 0 || data_fmt == AmdGpu::DataFormat::FormatInvalid)) {'''
if v.count(old1)!=1: raise SystemExit('STOP: fixed-image null check changed')
v=v.replace(old1,new1,1)
old2='''        if (!memory->IsValidGpuMapping(tsharp.Address(), 0) ||\n            !magic_enum::enum_contains(data_fmt) || !magic_enum::enum_contains(num_fmt)) {'''
new2='''        if ((!image_desc.ghost_dynamic_image_count &&\n             !memory->IsValidGpuMapping(tsharp.Address(), 0)) ||\n            !magic_enum::enum_contains(data_fmt) || !magic_enum::enum_contains(num_fmt)) {'''
if v.count(old2)!=1: raise SystemExit('STOP: fixed-image mapping check changed')
v=v.replace(old2,new2,1)

# A late-populated table can still contain empty rows. Bind those individual
# elements as null instead of feeding an address-zero image to TextureCache.
old3='''            auto& [image_id, desc] = image_bindings[num_images++];\n            std::construct_at(&desc, selected, image_desc);'''
new3='''            auto& [image_id, desc] = image_bindings[num_images++];\n            if (image_desc.ghost_dynamic_image_count &&\n                (selected.Address() == 0 || !selected.Valid() ||\n                 !memory->IsValidGpuMapping(selected.Address(), 0))) {\n                image_id = {};\n                desc.type = image_desc.is_written\n                                ? VideoCore::TextureCache::BindingType::Storage\n                                : VideoCore::TextureCache::BindingType::Texture;\n                continue;\n            }\n            if (image_desc.ghost_dynamic_image_count && tsharp.Address() == 0) {\n                static std::atomic<u32> late_rows_logged{};\n                if (late_rows_logged.fetch_add(1, std::memory_order_relaxed) < 24) {\n                    LOG_WARNING(Render_Vulkan,\n                                "GOT56_RUNTIME_DYNAMIC_ROW shader={:#x} slot={} row={} address={:#x} data_format={} num_format={}",\n                                stage.pgm_hash, image_desc.ghost_dynamic_image_slot, i,\n                                selected.Address(), u32(selected.GetDataFmt()),\n                                u32(selected.GetNumberFmt()));\n                }\n            }\n            std::construct_at(&desc, selected, image_desc);'''
if v.count(old3)!=1: raise SystemExit('STOP: Ghost selected-row bind block changed')
v=v.replace(old3,new3,1)

for marker in ('GOT56_RUNTIME_DYNAMIC_ROW','ghost_dynamic_image_count','candidate.GetViewType(image_desc.is_array) =='):
    if marker not in v: raise SystemExit('STOP: v56 rasterizer static check failed: '+marker)
rast_dst.parent.mkdir(parents=True,exist_ok=True)
if rast_dst.exists() and rast_dst.read_text()!=v: raise SystemExit('STOP: existing v56 rasterizer source differs')
rast_dst.write_text(v)
print('SOURCE_PREFLIGHT=PASS')
PY

python3 - "$V31" "$V51" "$V55" "$V56" "$RES" "$RAST" <<'PY'
from pathlib import Path
import json,os,subprocess,sys
v31,v51,v55,v56=map(Path,sys.argv[1:5]); res=sys.argv[5]; rast=sys.argv[6]; b=v56/'build'

def redirected(argv, oldsrc, newsrc, newobj):
    argv=list(argv)
    if argv.count(oldsrc)!=1 or argv.count('-o')!=1: raise SystemExit('STOP: compile manifest source/output differs')
    oldobj=argv[argv.index('-o')+1]
    argv=[newsrc if x==oldsrc else x for x in argv]
    argv[argv.index('-o')+1]=newobj
    if '-MF' in argv: argv[argv.index('-MF')+1]=newobj+'.d'
    if '-MT' in argv: argv[argv.index('-MT')+1]=newobj
    return argv,oldobj

res_cc=json.loads((v55/'build/compile-argv.json').read_text())
res_obj=str(b/'resource_patching_pass.cpp.o')
res_cc,old_res_obj=redirected(res_cc,str(v55/res),str(v56/res),res_obj)

rast_cc=json.loads((v51/'build/compile-argv.json').read_text())
rast_obj=str(b/'vk_rasterizer.cpp.o')
rast_cc,old_rast_obj=redirected(rast_cc,str(v51/rast),str(v56/rast),rast_obj)

ld=json.loads((v55/'build/link-argv.json').read_text())
if ld.count('-o')!=1: raise SystemExit('STOP: v55 link output differs')
res_hits=[i for i,x in enumerate(ld) if x==old_res_obj or x.endswith('/CMakeFiles/shadps4.dir/'+res+'.o')]
rast_hits=[i for i,x in enumerate(ld) if x==old_rast_obj or x.endswith('/CMakeFiles/shadps4.dir/'+rast+'.o')]
if len(res_hits)!=1 or len(rast_hits)!=1 or res_hits[0]==rast_hits[0]:
    raise SystemExit(f'STOP: v55 link object match differs res={res_hits} rast={rast_hits}')
ld[res_hits[0]]=res_obj; ld[rast_hits[0]]=rast_obj
pending=str(b/'shadps4.pending'); ld[ld.index('-o')+1]=pending
ld=[x.replace(str(v55/'build/link.d'),str(b/'link.d')) for x in ld]
for name,obj in (('resource',Path(res_obj)),('rasterizer',Path(rast_obj))):
    obj.parent.mkdir(parents=True,exist_ok=True)
    for p in (obj,Path(str(obj)+'.d')):
        if p.is_symlink(): raise SystemExit('STOP: unsafe '+name+' output')
        if p.exists(): p.unlink()
if Path(pending).exists(): Path(pending).unlink()
for name,argv in (('resource',res_cc),('rasterizer',rast_cc)):
    print('STAGE=COMPILE_'+name.upper(),flush=True)
    with (b/(name+'-compile.log')).open('wb') as f:
        r=subprocess.run(argv,cwd=v31/'build',stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT)
    if r.returncode: raise SystemExit('STOP: '+name+' compile failed; '+str(b/(name+'-compile.log')))
print('STAGE=RELINK_V55_WITH_V56_DYNAMIC_BINDING',flush=True)
with (b/'link.log').open('wb') as f:
    r=subprocess.run(ld,cwd=v31/'build',stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT)
if r.returncode: raise SystemExit('STOP: link failed; '+str(b/'link.log'))
out=b/'shadps4'; os.replace(pending,out); out.chmod(0o700)
(b/'compile-resource-argv.json').write_text(json.dumps(res_cc,indent=2)+'\n')
(b/'compile-rasterizer-argv.json').write_text(json.dumps(rast_cc,indent=2)+'\n')
(b/'link-argv.json').write_text(json.dumps(ld,indent=2)+'\n')
PY

SHA56="$(sha "$V56/build/shadps4")"
echo "BUILD=V56_READY SHA=$SHA56"

RUN="$P/play/manual-v56-direct"
if [[ ! -d "$RUN" ]]; then
  SRC_RUN=''
  for x in "$P/play/manual-v55-direct" "$P/play/manual-v54-direct" "$P/play/manual-v53-direct" "$P/play/manual-v53" "$P/play/manual-v51"; do
    if [[ -d "$x/user" && ! -L "$x" ]]; then SRC_RUN="$x"; break; fi
  done
  [[ -n "$SRC_RUN" ]] || fail 'no preserved manual GoT profile found'
  if find "$SRC_RUN" -type l -print -quit | grep -q .; then fail 'symlink in preserved manual profile'; fi
  TMP="$(mktemp -d "$P/play/.manual-v56-XXXXXXXX")"
  cp -a "$SRC_RUN/." "$TMP/"
  rm -f "$TMP/shadps4"
  cp "$V56/build/shadps4" "$TMP/shadps4"
  chmod 700 "$TMP/shadps4"
  printf 'source_profile=%s\nbinary_sha256=%s\nautomatic_input=false\n' "$SRC_RUN" "$SHA56" > "$TMP/v56-runtime.txt"
  mv "$TMP" "$RUN"
fi
[[ "$(sha "$RUN/shadps4")" == "$SHA56" ]] || fail 'v56 runtime binary mismatch'
if pgrep -u "$(id -u)" -x shadps4 >/dev/null; then fail 'another shadPS4 is running'; fi

STAMP="$(date +%Y%m%d-%H%M%S)"
REPORT="$LOGROOT/got-v56-manual-$STAMP"
mkdir -p "$REPORT"/{info,logs,screenshots,radv-home,spirv-failures}
RUNNER="$REPORT/info/worker.sh"
cat > "$RUNNER" <<RUN
#!/usr/bin/env bash
set -uo pipefail
cd $(printf '%q' "$RUN")
export HOME=$(printf '%q' "$REPORT/radv-home")
export VK_DRIVER_FILES=$(printf '%q' "$ICD")
export VK_ICD_FILENAMES=$(printf '%q' "$ICD")
export RADV_DEBUG=hang,noumr
export MESA_SHADER_CACHE_DISABLE=true
export MESA_SPIRV_FAIL_DUMP_PATH=$(printf '%q' "$REPORT/spirv-failures")
export SHADPS4_GHOST_BINDLESS_EXPERIMENT=1
export SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS=1
./shadps4 --cpu-id-mode=native --game $(printf '%q' "$GAME") --fullscreen true >$(printf '%q' "$REPORT/logs/game-stdout.log") 2>&1 &
game=\$!
( last=0; for target in 20 75 120 180 240 300 420 600; do delay=\$((target-last)); sleep "\$delay"; last=\$target; kill -0 "\$game" 2>/dev/null || break; wid=\$(xdotool search --onlyvisible --pid "\$game" 2>/dev/null | tail -n1 || true); if [[ -n "\$wid" ]]; then import -window "\$wid" $(printf '%q' "$REPORT/screenshots")/\${target}s.png 2>/dev/null || true; fi; done ) & shot=\$!
wait "\$game"; rc=\$?
kill "\$shot" 2>/dev/null || true; wait "\$shot" 2>/dev/null || true
echo "\$rc" >$(printf '%q' "$REPORT/info/exit-code.txt")
tar -czf $(printf '%q' "$REPORT.tar.gz") -C $(printf '%q' "$REPORT") info logs screenshots 2>/dev/null || true
exit "\$rc"
RUN
chmod 700 "$RUNNER"

ENVARGS=()
for k in DISPLAY XAUTHORITY XDG_RUNTIME_DIR DBUS_SESSION_BUS_ADDRESS PULSE_SERVER PIPEWIRE_REMOTE SDL_GAMECONTROLLERCONFIG SDL_GAMECONTROLLERCONFIG_FILE; do
  [[ -n "${!k:-}" ]] && ENVARGS+=("--setenv=$k=${!k}")
done
UNIT="got-v56-manual-$STAMP.service"
systemd-run --user --collect --no-block --service-type=exec --unit="$UNIT" \
  --description='GoT v56 late dynamic texture binding' --property=TimeoutStopSec=30s --property=KillMode=control-group \
  --working-directory="$RUN" --setenv="HOME=$HOME" --setenv='PATH=/usr/local/bin:/usr/bin:/bin' \
  "${ENVARGS[@]}" /usr/bin/bash "$RUNNER"
printf 'REPORT=%s\nARCHIVE=%s\nUNIT=%s\n' "$REPORT" "$REPORT.tar.gz" "$UNIT" > "$LOGROOT/.got-v56-manual-latest"
echo 'V56_STARTED=YES'
echo 'INPUT=MANUAL_GAMEPAD'
echo 'AUTOMATIC_INPUT=NONE'
echo "QUIT=systemctl --user stop $UNIT"
echo "WHEN_FINISHED_UPLOAD=$REPORT.tar.gz"
