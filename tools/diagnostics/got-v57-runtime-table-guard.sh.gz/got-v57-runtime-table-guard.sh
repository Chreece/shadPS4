#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

P="$HOME/projects/shadps4/GhostOfTsushima"
T="$P/tests"
L="$HOME/projects/shadps4/logs"
V31="$T/got-v31-nptoolkit-mspace-20261013"
V51="$T/got-v51-stencil-reference-20261014"
V55="$T/got-v55-empty-dynamic-slot-null-20261014"
V56="$T/got-v56c-late-dynamic-bindless-20261014"
V57="$T/got-v57-runtime-table-guard-20261014"
RAST='src/video_core/renderer_vulkan/vk_rasterizer.cpp'
DRV="$P/tools/radv-nuw-complete-25.0.7/libvulkan_radeon.so"
ICD="$P/tools/radv-nuw-complete-25.0.7/radeon_icd.json"
GAME='/mnt/roms-all/ps4-games/CUSA11456/eboot.bin'
DRV_SHA='87908e0c6833c0f6dc86cb079cb0f34de0dee7e970da89b5303f0e6b29e326f7'
sha(){ sha256sum "$1" | cut -d' ' -f1; }
fail(){ echo "STOP: $*" >&2; exit 2; }

[[ "$(id -u)" != 0 ]] || fail 'run without sudo'
if pgrep -u "$(id -u)" -x shadps4 >/dev/null; then fail 'another shadPS4 is running'; fi
[[ -x "$V56/build/shadps4" && -f "$V56/$RAST" ]] || fail 'completed v56c build/source missing'
[[ -x "$V55/build/shadps4" && -f "$V55/build/link-argv.json" ]] || fail 'v55 link baseline missing'
[[ -f "$V51/build/compile-argv.json" ]] || fail 'v51 rasterizer compile manifest missing'
[[ -x "$V31/build/shadps4" ]] || fail 'v31 build baseline missing'
[[ -f "$DRV" && "$(sha "$DRV")" == "$DRV_SHA" && -f "$ICD" ]] || fail 'private RADV changed/missing'
[[ -f "$GAME" ]] || fail 'GoT eboot missing'
[[ -f "$V56/build/resource_patching_pass.cpp.o" ]] || fail 'v56c resource object missing'
[[ -d "$P/play/manual-v56c-direct/user" ]] || fail 'v56c manual profile missing'

# New candidate only. Never overwrite v55/v56c.
if [[ -e "$V57" || -L "$V57" ]]; then
  [[ -d "$V57" && ! -L "$V57" ]] || fail 'unsafe existing v57 path'
  rm -rf -- "$V57"
fi
mkdir -p "$V57/$(dirname "$RAST")" "$V57/build" "$L"

python3 - "$V56/$RAST" "$V57/$RAST" <<'PY'
from pathlib import Path
import re,sys
src,dst=map(Path,sys.argv[1:])
s=src.read_text()
if 'GOT56_RUNTIME_DYNAMIC_ROW' not in s:
    raise SystemExit('STOP: v56c runtime-row correction missing')

# Locate the exact BindTextures function by brace balance, not by a guessed next function.
m=re.search(r'(?m)^void Rasterizer::BindTextures\([^\n]*\)\s*\{',s)
if not m or len(re.findall(r'(?m)^void Rasterizer::BindTextures\(',s)) != 1:
    raise SystemExit('STOP: BindTextures function not uniquely found')
depth=1; pos=m.end()
while pos < len(s) and depth:
    if s[pos]=='{': depth+=1
    elif s[pos]=='}': depth-=1
    pos+=1
if depth:
    raise SystemExit('STOP: BindTextures braces are unbalanced')
lo,hi=m.start(),pos
fn=s[lo:hi]

msg='"Ghost dynamic T# table no longer matches 53 x 340"'
if fn.count(msg) != 1:
    raise SystemExit('STOP: runtime table assertion message count='+str(fn.count(msg)))
start=fn.rfind('ASSERT_MSG(',0,fn.index(msg))
if start < 0:
    raise SystemExit('STOP: runtime table ASSERT_MSG start missing')
# This assertion ends at the first ); following its unique message.
end=fn.find(');',fn.index(msg))
if end < 0:
    raise SystemExit('STOP: runtime table ASSERT_MSG end missing')
end += 2
assertion=fn[start:end]
for required in ('table_size == sizeof(table)','table.base_address != 0',
                 'table.GetStride() == 340','table.GetSize() == 18020'):
    if required not in assertion:
        raise SystemExit('STOP: runtime table assertion shape changed: '+required)

replacement='''const bool ghost_table_matches =\n                table_size == sizeof(table) && table.base_address != 0 &&\n                table.GetStride() == 340 && table.GetSize() == 18020 &&\n                table.base_address <=\n                    0x00007fffffffffffull - (52 * 340 + 6 * 32 + sizeof(AmdGpu::Image));\n            if (!ghost_table_matches) {\n                static std::atomic<u32> mismatched_tables_logged{};\n                if (mismatched_tables_logged.fetch_add(1, std::memory_order_relaxed) < 24) {\n                    LOG_WARNING(Render_Vulkan,\n                                "GOT57_DYNAMIC_TABLE_MISMATCH shader={:#x} slot={} root={:#x} read={} base={:#x} stride={} size={} action=null_this_draw",\n                                stage.pgm_hash, image_desc.ghost_dynamic_image_slot, root,\n                                table_size, u64(table.base_address), table.GetStride(), table.GetSize());\n                }\n            }'''
fn=fn[:start]+replacement+fn[end:]
loop='for (u32 row = 0; row < 53; ++row) {'
if fn.count(loop) != 1:
    raise SystemExit('STOP: Ghost 53-row runtime loop count='+str(fn.count(loop)))
fn=fn.replace(loop,'for (u32 row = 0; ghost_table_matches && row < 53; ++row) {',1)

out=s[:lo]+fn+s[hi:]
if out.count('GOT57_DYNAMIC_TABLE_MISMATCH') != 1:
    raise SystemExit('STOP: v57 marker verification failed')
if out.count('GOT56_RUNTIME_DYNAMIC_ROW') != 1:
    raise SystemExit('STOP: v56c runtime binding was not preserved exactly once')
dst.write_text(out)
print('SOURCE_PREFLIGHT=PASS')
PY

python3 - "$V31" "$V51" "$V55" "$V56" "$V57" "$RAST" <<'PY'
from pathlib import Path
import json,os,subprocess,sys
v31,v51,v55,v56,v57=map(Path,sys.argv[1:6]); rel=sys.argv[6]; b=v57/'build'
cc=json.loads((v51/'build/compile-argv.json').read_text())
oldsrc=str(v51/rel); newsrc=str(v57/rel)
if cc.count(oldsrc)!=1 or cc.count('-o')!=1:
    raise SystemExit('STOP: v51 rasterizer compile manifest changed')
oldout=cc[cc.index('-o')+1]; newobj=str(b/'vk_rasterizer.cpp.o')
cc=[newsrc if x==oldsrc else x for x in cc]
cc[cc.index('-o')+1]=newobj
if '-MF' in cc: cc[cc.index('-MF')+1]=newobj+'.d'
if '-MT' in cc: cc[cc.index('-MT')+1]=newobj

ld=json.loads((v55/'build/link-argv.json').read_text())
if ld.count('-o')!=1: raise SystemExit('STOP: v55 linker output shape changed')
res_suffix='/CMakeFiles/shadps4.dir/src/shader_recompiler/ir/passes/resource_patching_pass.cpp.o'
rast_suffix='/CMakeFiles/shadps4.dir/src/video_core/renderer_vulkan/vk_rasterizer.cpp.o'
res_hits=[i for i,x in enumerate(ld) if x.endswith(res_suffix)]
rast_hits=[i for i,x in enumerate(ld) if x.endswith(rast_suffix)]
if len(res_hits)!=1 or len(rast_hits)!=1 or res_hits[0]==rast_hits[0]:
    raise SystemExit(f'STOP: link objects differ res={res_hits} rast={rast_hits}')
res56=v56/'build/resource_patching_pass.cpp.o'
if not res56.is_file(): raise SystemExit('STOP: v56c resource object missing')
ld[res_hits[0]]=str(res56)
ld[rast_hits[0]]=newobj
pending=str(b/'shadps4.pending')
oldlink=ld[ld.index('-o')+1]
ld[ld.index('-o')+1]=pending
ld=[x.replace(str(v55/'build/link.d'),str(b/'link.d')) for x in ld]

for p in (Path(newobj),Path(newobj+'.d'),Path(pending)):
    if p.is_symlink(): raise SystemExit('STOP: unsafe candidate output '+str(p))
    if p.exists(): p.unlink()
print('STAGE=COMPILE_RASTERIZER_ONLY',flush=True)
with (b/'compile.log').open('wb') as f:
    r=subprocess.run(cc,cwd=v31/'build',stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT)
if r.returncode: raise SystemExit('STOP: rasterizer compile failed; '+str(b/'compile.log'))
print('STAGE=RELINK_V56C_WITH_V57_TABLE_GUARD',flush=True)
with (b/'link.log').open('wb') as f:
    r=subprocess.run(ld,cwd=v31/'build',stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT)
if r.returncode: raise SystemExit('STOP: link failed; '+str(b/'link.log'))
out=b/'shadps4'; os.replace(pending,out); out.chmod(0o700)
(b/'compile-argv.json').write_text(json.dumps(cc,indent=2)+'\n')
(b/'link-argv.json').write_text(json.dumps(ld,indent=2)+'\n')
PY

SHA57="$(sha "$V57/build/shadps4")"
[[ "$SHA57" != "$(sha "$V56/build/shadps4")" ]] || fail 'v57 binary unchanged'
echo "BUILD=V57_READY SHA=$SHA57"

RUN="$P/play/manual-v57-direct"
if [[ ! -d "$RUN" ]]; then
  if find "$P/play/manual-v56c-direct" -type l -print -quit | grep -q .; then fail 'symlink in v56c profile'; fi
  TMP="$(mktemp -d "$P/play/.manual-v57-XXXXXXXX")"
  cp -a "$P/play/manual-v56c-direct/." "$TMP/"
  rm -f "$TMP/shadps4"
  cp "$V57/build/shadps4" "$TMP/shadps4"
  chmod 700 "$TMP/shadps4"
  printf 'source_profile=%s\nbinary_sha256=%s\nautomatic_input=false\n' "$P/play/manual-v56c-direct" "$SHA57" > "$TMP/v57-runtime.txt"
  mv "$TMP" "$RUN"
fi
[[ "$(sha "$RUN/shadps4")" == "$SHA57" ]] || fail 'v57 runtime binary mismatch'

STAMP="$(date +%Y%m%d-%H%M%S)"
REPORT="$L/got-v57-manual-$STAMP"
mkdir -p "$REPORT"/{info,logs,screenshots,radv-home,spirv-failures}
RUNNER="$REPORT/info/worker.sh"
cat > "$RUNNER" <<RUN
#!/usr/bin/env bash
set -uo pipefail
cd $(printf '%q' "$RUN")
export HOME=$(printf '%q' "$REPORT/radv-home")
export VK_DRIVER_FILES=$(printf '%q' "$ICD")
export VK_ICD_FILENAMES=$(printf '%q' "$ICD")
export RADV_DEBUG=hang,noumr
export MESA_SHADER_CACHE_DISABLE=true
export MESA_SPIRV_FAIL_DUMP_PATH=$(printf '%q' "$REPORT/spirv-failures")
export SHADPS4_GHOST_BINDLESS_EXPERIMENT=1
export SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS=1
./shadps4 --cpu-id-mode=native --game $(printf '%q' "$GAME") --fullscreen true >$(printf '%q' "$REPORT/logs/game-stdout.log") 2>&1 &
game=\$!
( last=0; for target in 20 60 120 180 240 300 420 600; do delay=\$((target-last)); sleep "\$delay"; last=\$target; kill -0 "\$game" 2>/dev/null || break; wid=\$(xdotool search --onlyvisible --pid "\$game" 2>/dev/null | tail -n1 || true); if [[ -n "\$wid" ]]; then import -window "\$wid" $(printf '%q' "$REPORT/screenshots")/\${target}s.png 2>/dev/null || true; fi; done ) & shot=\$!
wait "\$game"; rc=\$?
kill "\$shot" 2>/dev/null || true; wait "\$shot" 2>/dev/null || true
echo "\$rc" >$(printf '%q' "$REPORT/info/exit-code.txt")
tar -czf $(printf '%q' "$REPORT.tar.gz") -C $(printf '%q' "$REPORT") info logs screenshots 2>/dev/null || true
exit "\$rc"
RUN
chmod 700 "$RUNNER"
ENVARGS=()
for k in DISPLAY XAUTHORITY XDG_RUNTIME_DIR DBUS_SESSION_BUS_ADDRESS PULSE_SERVER PIPEWIRE_REMOTE SDL_GAMECONTROLLERCONFIG SDL_GAMECONTROLLERCONFIG_FILE; do
  [[ -n "${!k:-}" ]] && ENVARGS+=("--setenv=$k=${!k}")
done
UNIT="got-v57-manual-$STAMP.service"
systemd-run --user --collect --no-block --service-type=exec --unit="$UNIT" \
  --description='GoT v57 runtime table guard' --property=TimeoutStopSec=30s --property=KillMode=control-group \
  --working-directory="$RUN" --setenv="HOME=$HOME" --setenv='PATH=/usr/local/bin:/usr/bin:/bin' \
  "${ENVARGS[@]}" /usr/bin/bash "$RUNNER"
printf 'REPORT=%s\nARCHIVE=%s\nUNIT=%s\n' "$REPORT" "$REPORT.tar.gz" "$UNIT" > "$L/.got-v57-manual-latest"
echo 'V57_STARTED=YES'
echo 'INPUT=MANUAL_GAMEPAD'
echo 'AUTOMATIC_INPUT=NONE'
echo "QUIT=systemctl --user stop $UNIT"
echo "WHEN_FINISHED_UPLOAD=$REPORT.tar.gz"
