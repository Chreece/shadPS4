from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,time,sys
root=Path('/workspace/scratch/b37c1c69af35')
source=root/'cpu-xsave-native'; evidence=Path('/tmp/xstate-physical-validation');binary=Path(sys.argv[1])
profile_source=root/'cpu-xsave-evidence/hardware/ps4_reference'
game=evidence/'game';(game/'sce_sys').mkdir(parents=True,exist_ok=True)
shutil.copy2(evidence/'homebrew/eboot.bin',game/'eboot.bin')
shutil.copy2(root/'cpu-xsave-evidence/hardware/generated_reciprocal/param.sfo',game/'sce_sys/param.sfo')
shutil.copytree(root/'jaguar-tools/OpenOrbis/PS4Toolchain/samples/hello_world/sce_module',game/'sce_module',dirs_exist_ok=True)
env=dict(os.environ,DISPLAY='127.0.0.1:97',SDL_VIDEODRIVER='x11',ALSOFT_DRIVERS='null',SDL_AUDIODRIVER='dummy',SHADPS4_ENABLE_IPC='false',VK_DRIVER_FILES=str(root/'cpu-build-tools/root/usr/share/vulkan/icd.d/lvp_icd.json'))
# Null GPU avoids requesting any game graphics work.
summary={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'runtime_dependency':False,'profiles':{}}

with (evidence/(sys.argv[2]+'-xvfb.log')).open('w') as log:
 display=subprocess.Popen(['Xvfb',':97','-screen','0','640x360x24','-listen','tcp','-nolisten','unix','-nolisten','local','-ac'],stdout=log,stderr=subprocess.STDOUT,env=env)
 try:
  time.sleep(1)
  runtime=evidence/('runtime-'+sys.argv[2]);user=runtime/'user';user.mkdir(parents=True,exist_ok=True)
  users=[]
  for i in range(4):
   uid=1000+i
   for folder in ('savedata','trophy','inputs'):(user/'home'/str(uid)/folder).mkdir(parents=True,exist_ok=True)
   users.append({'user_id':uid,'user_name':'CPU State Test','user_color':i+1,'player_index':i+1,'shadnet_enabled':False})
  (user/'users.json').write_text(json.dumps({'Users':{'user':users}}))
  (user/'config.json').write_text(json.dumps({'GPU':{'null_gpu':True,'full_screen':False,'window_width':640,'window_height':360},'Log':{'filter':'*:Info','flush_level':'info','sync':True},'General':{'show_splash':False,'home_dir':str(user/'home'),'neo_mode':False}}))
  with (evidence/(sys.argv[2]+'-launch.log')).open('w') as output:
   rc=subprocess.run([str(binary),'--ignore-game-patch',str(game/'eboot.bin')],cwd=runtime,env=env,stdout=output,stderr=subprocess.STDOUT,timeout=90).returncode
  capture=user/'data/cpu-xstate-hardware.txt'
  if capture.exists():shutil.copy2(capture,evidence/(sys.argv[2]+'-xstate.txt'))
  print('exit',rc,'capture',capture.exists(),flush=True)
  assert rc==0
 finally:
  display.terminate();display.wait(timeout=5)
