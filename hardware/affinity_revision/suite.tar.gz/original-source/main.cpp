#include <sstream>

//warp start
#define sceKernelGetCompiledSdkVersion sceKernelGetCompiledSdkVersion_orig
#define scePthreadGetaffinity          scePthreadGetaffinity_orig
#define scePthreadSetaffinity          scePthreadSetaffinity_orig
#define sceSystemServiceGetStatus      sceSystemServiceGetStatus_orig

#include <stdint.h>
#include <string>
#include <sys/types.h>
#include <orbis/_types/kernel.h>
#include <orbis/_types/pthread.h>
#include <orbis/_types/errors.h>
#include <orbis/_types/user.h>
#include <orbis/_types/video.h>

#include <orbis/libkernel.h>
#include <orbis/SystemService.h>
#include <orbis/UserService.h>

#include <orbis/Sysmodule.h>
#include <orbis/_types/sysmodule.h>

//warp end
#undef sceKernelGetCompiledSdkVersion
#undef scePthreadGetaffinity
#undef scePthreadSetaffinity
#undef sceSystemServiceGetStatus

//#include <orbis/Rtc.h>

//#include <orbis/libkernel.h>

#define O_RDONLY  0x0000 // open for reading only 
#define O_WRONLY  0x0001 // open for writing only 
#define O_RDWR    0x0002 // open for reading and writing 
#define O_ACCMODE 0x0003 // mask for above modes 

#define O_NONBLOCK 0x0004 // no delay 
#define O_APPEND   0x0008 // set append mode 

#define O_SHLOCK  0x0010 // open with shared file lock 
#define O_EXLOCK  0x0020 // open with exclusive file lock 
#define O_ASYNC   0x0040 // signal pgrp when data ready 
#define O_FSYNC   0x0080 // synchronous writes 

#define O_SYNC     0x0080 // POSIX synonym for O_FSYNC 
#define O_NOFOLLOW 0x0100 // don't follow symlinks 
#define O_CREAT    0x0200 // create if nonexistent 
#define O_TRUNC    0x0400 // truncate to zero length 
#define O_EXCL     0x0800 // error if already exists 
#define O_DSYNC    0x1000 // synchronous data writes(omit inode writes) 
#define FHASLOCK   0x4000 // descriptor holds advisory lock 

#define O_NOCTTY  0x8000 //don't assign controlling terminal 

// Attempt to bypass buffer cache 
#define O_DIRECT  0x00010000

// Defined by POSIX Extended API Set Part 2 
#define O_DIRECTORY  0x00020000 // Fail if not directory 
#define O_EXEC       0x00040000 // Open for execute only 

#define	SCE_DBG_MAX_NAME_LENGTH 256
#define	SCE_DBG_MAX_SEGMENTS      4
#define	SCE_DBG_NUM_FINGERPRINT  20

#define ORBIS_MAX_PATH  255

struct OrbisKernelDirent {
    int      d_fileno;                    /* file number of entry */
    uint16_t d_reclen;                    /* length of this record */
    uint8_t  d_type;                      /* file type, see below */
    uint8_t  d_namlen;                    /* length of string in d_name */
    char     d_name[ORBIS_MAX_PATH + 1];  /* name must be no longer than this */
};

//mmap flags
#define MAP_SHARED             0x00001   // share changes
#define MAP_PRIVATE            0x00002   // changes are private
#define MAP_FIXED              0x00010   // map addr must be exactly as requested
#define MAP_NO_OVERWRITE       0x00080   // don't overwrite memory with MAP_FIXED
#define MAP_VOID               0x00100   // reserve addr
#define MAP_HASSEMAPHORE       0x00200   // region may contain semaphores
#define MAP_STACK              0x00400   // region grows down, like a stack
#define MAP_NOSYNC             0x00800   // page to but do not sync underlying file
#define MAP_FILE               0x00000   // map from file (default)
#define MAP_ANON               0x01000   // allocated from memory, swap space
#define MAP_ANONYMOUS          MAP_ANON  // For compatibility.
#define MAP_SYSTEM             0x02000
#define MAP_ALLAVAILABLE       0x04000
#define MAP_NOCORE             0x20000   // dont include these pages in a coredump
#define MAP_PREFAULT_READ      0x40000   // prefault mapping for reading
#define MAP_SELF               0x80000   // map decryped SELF file
                               
#define MAP_SANITIZER          0x200000  // devkit only
#define MAP_NO_COALESCE        0x400000  // do not merge nearby areas
#define MAP_WRITABLE_WB_GARLIC 0x800000  // allow write to WB_GARLIC      

//eflags
#define MAP_ENTRY_NOSYNC           0x0001
#define MAP_ENTRY_IS_SUB_MAP       0x0002
#define MAP_ENTRY_COW              0x0004
#define MAP_ENTRY_NEEDS_COPY       0x0008
#define MAP_ENTRY_NOFAULT          0x0010
#define MAP_ENTRY_USER_WIRED       0x0020
                                   
#define MAP_ENTRY_BEHAV_NORMAL     0x0000 // default behavior
#define MAP_ENTRY_BEHAV_SEQUENTIAL 0x0040 // expect sequential access
#define MAP_ENTRY_BEHAV_RANDOM     0x0080 // expect random access
#define MAP_ENTRY_BEHAV_RESERVED   0x00C0 // future use

#define MAP_ENTRY_BEHAV_MASK       0x00C0

#define MAP_ENTRY_IN_TRANSITION    0x0100 // entry being changed
#define MAP_ENTRY_NEEDS_WAKEUP     0x0200 // waiters in transition
#define MAP_ENTRY_NOCOREDUMP       0x0400 // don't include in a core

#define MAP_ENTRY_WIRE_LOCK        0x0800 // lock to user unwire

#define MAP_ENTRY_GROWS_DOWN       0x1000 // Top-down stacks
#define MAP_ENTRY_GROWS_UP         0x2000 // Bottom-up stacks
                                   
#define MAP_ENTRY_WIRE_SKIPPED     0x4000
                                   
#define MAP_ENTRY_SUSPENDED        0x8000
                                   
#define MAP_ENTRY_VN_WRITECNT      0x10000 // writeable vnode mapping
                                   
#define MAP_ENTRY_IN_TRANSITION2   0x20000 // vm_map_type_protect,kern_mmap_dmem
                                   
#define MAP_ENTRY_KERNEL           0x40000 // MAP_COW_KERNEL
#define MAP_ENTRY_MMAP_DMEM        0x80000 // sys_mmap_dmem
                                   
#define MAP_ENTRY_WIRE_BUDGET      0x100000 // entry in wire budget
#define MAP_ENTRY_IN_BUDGET        0x200000 // entry in budget
#define MAP_ENTRY_NO_COALESCE      0x400000 // do not merge nearby areas     

////

struct OrbisSystemServiceStatus {
    int32_t eventNum;
    bool isSystemUiOverlaid;
    bool isInBackgroundExecution;
    bool isCpuMode7CpuNormal;
    bool isGameLiveStreamingOnAir;
    bool isOutOfVrPlayArea;
    char reserved[125];
};


#ifdef __cplusplus 
extern "C" {
#endif

int32_t sceKernelUsleep(uint32_t);

int32_t sceKernelGetCompiledSdkVersion(uint32_t* dst);

int32_t sceKernelGetCurrentCpu();
int32_t sceKernelGetCpumode();

int32_t pthread_getaffinity_np(pthread_t thread, uint64_t cpusetsize, void* cpuset);
int32_t pthread_setaffinity_np(pthread_t thread, uint64_t cpusetsize, void* cpuset);

int32_t scePthreadGetaffinity(pthread_t thread, uint64_t* mask);
int32_t scePthreadSetaffinity(pthread_t thread, uint64_t mask);

pthread_t pthread_self();
pthread_t scePthreadSelf();

int32_t sceSystemServiceGetStatus(OrbisSystemServiceStatus* status);

#ifdef __cplusplus
}
#endif

const char* PASS[2] = { "[Test FAILED!]", "[Test passed!]" };

uint g_sdk_version = 0;



const char* CPUMODE_STR[8] = {
    "6CPU",     
    "7CPU_LOW", 
    "COMPAT",
    "","",
    "7CPU_NORMAL",
    "",""
};



int main(void)
{
    // No buffering
    setvbuf(stdout, NULL, _IONBF, 0);

    sceKernelGetCompiledSdkVersion(&g_sdk_version);

    printf("    sceKernelGetCompiledSdkVersion=0x%08x\n", g_sdk_version);

    int attr_mode;
    int attr_mask;
 
    if (g_sdk_version < 0x3000000) {
        attr_mode = 2; //COMPAT
        attr_mask = 0x3f;
    }
    else {
        int mode = (g_sdk_version >> 15) & 3;

        switch (mode) {
        case 0:
            attr_mode = 5; //7CPU_NORMAL
            attr_mask = 0x7f;
            break;
        case 1:
            attr_mode = 0; //6CPU
            attr_mask = 0x3f;
            break;
        case 2:
            attr_mode = 5; //7CPU_NORMAL
            attr_mask = 0x7f;
            break;
        case 3:
            attr_mode = 2; //COMPAT
            attr_mask = 0x3f;
            break;
        };
    }

    printf("    attr_mode             =%d(%s)\n", attr_mode, CPUMODE_STR[attr_mode & 7]);
    printf("    attr_mask             =0x%016llx\n", attr_mask);

    int ret;

    OrbisSystemServiceStatus status = {};

    ret = sceSystemServiceGetStatus(&status);
    printf("    sceSystemServiceGetStatus=%d\n"   , ret);
    printf("     eventNum                =%d\n"   , status.eventNum);
    printf("     isSystemUiOverlaid      =%d\n"   , status.isSystemUiOverlaid      );
    printf("     isInBackgroundExecution =%d\n"   , status.isInBackgroundExecution );
    printf("     isCpuMode7CpuNormal     =%d %s\n", status.isCpuMode7CpuNormal     ,PASS[status.isCpuMode7CpuNormal == (attr_mode==5)]);
    printf("     isGameLiveStreamingOnAir=%d\n"   , status.isGameLiveStreamingOnAir);
    printf("     isOutOfVrPlayArea       =%d\n"   , status.isOutOfVrPlayArea       );

    //printf("   sizeof(pthread_t)=%d\n", sizeof(pthread_t));

    int cur_cpu;

    cur_cpu = sceKernelGetCurrentCpu();
    printf("    sceKernelGetCurrentCpu=%d\n", cur_cpu);

    int cpumode = sceKernelGetCpumode();

    printf("    sceKernelGetCpumode   =%d(%s) %s\n", cpumode, CPUMODE_STR[cpumode & 7], PASS[cpumode == attr_mode]);

    uint64_t mask;

    mask = 0;
    ret = scePthreadGetaffinity(scePthreadSelf(), &mask);
    printf("    scePthreadGetaffinity =%d 0x%016llx %s\n", ret, mask, PASS[mask == attr_mask]);

    mask = 0;
    ret = pthread_getaffinity_np(pthread_self(), 1, &mask);
    printf("    pthread_getaffinity_np(1)=%d 0x%016llx %s\n", ret, mask, PASS[ret == 34]);

    mask = 0;
    ret = pthread_getaffinity_np(pthread_self(), 8, &mask);
    printf("    pthread_getaffinity_np(8)=%d 0x%016llx %s\n", ret, mask, PASS[mask == attr_mask]);

    printf("-\n");

    //int32_t pthread_setaffinity_np(pthread_t thread, uint64_t cpusetsize, void* cpuset);
    //int32_t scePthreadSetaffinity(pthread_t thread, uint64_t mask);

    if (attr_mask == 0x3f) {

        int new_mask = 0x7f;
        ret = scePthreadSetaffinity(scePthreadSelf(), new_mask);
        printf("    scePthreadSetaffinity(0x%016llx)=%d %s\n", new_mask, ret, PASS[ret == -2147352575]);

        mask = 0;
        ret = scePthreadGetaffinity(scePthreadSelf(), &mask);
        printf("    scePthreadGetaffinity =%d 0x%016llx %s\n", ret, mask, PASS[mask == attr_mask]);

    };
   
    if (attr_mask == 0x7f) {

        int new_mask = 0xff;
        ret = scePthreadSetaffinity(scePthreadSelf(), new_mask);
        printf("    scePthreadSetaffinity(0x%016llx)=%d %s\n", new_mask, ret, PASS[ret == -2147352575]);

        mask = 0;
        ret = scePthreadGetaffinity(scePthreadSelf(), &mask);
        printf("    scePthreadGetaffinity =%d 0x%016llx %s\n", ret, mask, PASS[mask == attr_mask]);

    };

    int i = 0;
    while (((1 << i) & mask) != 0) {

        int new_mask = (1 << i);

        ret = scePthreadSetaffinity(scePthreadSelf(), new_mask);
        printf("    scePthreadSetaffinity(0x%016llx)=%d\n", new_mask, ret);

        cur_cpu = sceKernelGetCurrentCpu();
        printf("    sceKernelGetCurrentCpu=%d %s\n", cur_cpu, PASS[i == cur_cpu]);
        
        i++;
    };


    printf("-\n-\n-\n-\n-\n");

    ////////////

    sceSystemServiceLoadExec("EXIT", NULL);
}